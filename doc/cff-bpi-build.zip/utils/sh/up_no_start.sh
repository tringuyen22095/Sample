#!/bin/bash

docker-compose \
-f ./docker-compose.yml \
-f ./docker-compose-oru.yml \
-f ./docker-compose-cf.yml \
-f ./docker-compose-s1.yml \
-f ./docker-compose-oldbac.yml \
up --no-start


