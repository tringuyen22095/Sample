#!/bin/bash

src_repo="docker-registry.crifnet.com/cff"
dest_repo="docker-registry.crifnet.com/aslom"

root_folder=$1
compose_file=$2
new_tag=$3
test_mode=false

POSITIONAL=()
while [[ $# -gt 3 ]]
do
key="$4"

case $key in
    -t|--test)
    test_mode=true
    shift # past argument
    ;;
#    -s|--searchpath)
#    SEARCHPATH="$2"
#    shift # past argument
#    shift # past value
#    ;;
#    -l|--lib)
#    LIBPATH="$2"
#    shift # past argument
#    shift # past value
#    ;;
#    --default)
#    DEFAULT=YES
#    shift # past argument
#    ;;
    *)    # unknown option
    POSITIONAL+=("$1") # save it in an array for later
    shift # past argument
    ;;
esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters

echo ""
echo "  ROOT FOLDER          = ${root_folder}"
echo "  DOCKER-COMPOSE FILE  = ${compose_file}"
echo "  TAG TO APPLY         = ${new_tag}"
echo "  TEST MODE            = ${test_mode}"
echo ""
echo ""


echo "cd in root folder..."
pushd $root_folder
echo ""

# get image names without tags for all started containers
image_tags=$(docker-compose -f "$compose_file" images -q | xargs docker inspect --format='{{ index .RepoTags 0}}')

echo "current images pulled for file $compose_file"
echo "$image_tags"
echo ""

# iterate over images and re-tag
echo "retagging images..."
for image_tag in ${image_tags}
do
    curr_image_no_tag=$(echo ${image_tag} | cut -d':' -f1)
	dest_img=$(echo "${curr_image_no_tag/$src_repo/$dest_repo}")  
	
	echo "  ${image_tag} --> ${dest_img}:$new_tag"
	
	if [ "$test_mode" != true ] ; then
		docker tag "${image_tag}" "${dest_img}":$new_tag
		docker push "${dest_img}":$new_tag
	fi

done

popd > /dev/null

