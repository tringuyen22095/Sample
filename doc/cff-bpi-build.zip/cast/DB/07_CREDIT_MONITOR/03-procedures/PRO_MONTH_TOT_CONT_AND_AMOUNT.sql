create or replace PROCEDURE PRO_MONTH_TOT_CONT_AND_AMOUNT(P_PRODUCT_NAME IN VARCHAR2 ,
P_ORGANIZATION IN VARCHAR2 , 
P_PROCESS_NAME IN VARCHAR2 , 
CUR_RESPONSE_DETAILS OUT SYS_REFCURSOR,
P_GROUPVAR IN VARCHAR2)
AS
lv_condition1 varchar2(4000);
lv_condition2 varchar2(4000);
lv_condition3 varchar2(4000);
BEGIN
select case when P_PROCESS_NAME is not null  
             then ' and nvl(PROCESS_NAME,''xxx'') ='''||P_PROCESS_NAME||'''' else ' ' end,
         case   when P_PRODUCT_NAME is not null  
            then ' and nvl(PRODUCT_NAME,''xxx'') = '''||P_PRODUCT_NAME||'''' else ' ' end,
         case   when P_ORGANIZATION  is not null 
          THEN ' and nvl(ORGANIZATION,''xxx'') IN (' ||P_ORGANIZATION|| ')' else ' and nvl(ORGANIZATION,''xxx'') = ''NO_ORG'' ' end
               into lv_condition1,
              lv_condition2,
              lv_condition3
    from dual;
dbms_output.put_line ('SELECT '||P_GROUPVAR||' , COUNT(1) DISBURSED_CONTRACT, SUM(DISBURSED_AMOUNT) DISBURSED_AMOUNT, MAX(CURRENCY) CURRENCY
FROM CRE_MONI_DISB_DATA
WHERE PROCESS_DISB_COMPLETION_DATE > SYSDATE-30
'||lv_condition1||'              '||lv_condition2||'              '||lv_condition3||'
GROUP BY '||P_GROUPVAR || ' order by '||P_GROUPVAR);

OPEN CUR_RESPONSE_DETAILS
FOR
'SELECT '||P_GROUPVAR||' , COUNT(1) DISBURSED_CONTRACT, SUM(DISBURSED_AMOUNT) DISBURSED_AMOUNT, MAX(CURRENCY) CURRENCY
FROM CRE_MONI_DISB_DATA
WHERE PROCESS_DISB_COMPLETION_DATE > SYSDATE-30
'||lv_condition1||'              '||lv_condition2||'              '||lv_condition3||'
GROUP BY '||P_GROUPVAR || ' order by '||P_GROUPVAR;

EXCEPTION
  WHEN OTHERS
  THEN
NULL;
END;


