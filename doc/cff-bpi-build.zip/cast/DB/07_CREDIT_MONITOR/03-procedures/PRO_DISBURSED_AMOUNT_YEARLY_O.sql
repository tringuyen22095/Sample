create or replace PROCEDURE PRO_DISBURSED_AMOUNT_YEARLY_O(P_PRODUCT_NAME IN VARCHAR2 ,
P_ORGANIZATION IN VARCHAR2 , 
P_PROCESS_NAME IN VARCHAR2 , 
CUR_RESPONSE_DETAILS OUT SYS_REFCURSOR,
P_GROUPVAR IN VARCHAR2)
AS
lv_condition1 varchar2(4000);
lv_condition2 varchar2(4000);
lv_condition3 varchar2(4000);

BEGIN

select case when P_PROCESS_NAME is not null  
             then ' and nvl(PROCESS_NAME,''xxx'') ='''||P_PROCESS_NAME||'''' else ' ' end,
         case   when P_PRODUCT_NAME is not null  
            then ' and nvl(PRODUCT_NAME,''xxx'') = '''||P_PRODUCT_NAME||'''' else ' ' end,
         case   when P_ORGANIZATION  is not null 
            then ' and nvl(ORGANIZATION,''xxx'') = '''||P_ORGANIZATION||'''' else ' ' end
               into lv_condition1,
              lv_condition2,
              lv_condition3
    from dual;

OPEN CUR_RESPONSE_DETAILS
FOR
'WITH CTE_MAIN AS
(
              SELECT '||P_GROUPVAR||',TO_CHAR(DISBURSMENT_DATE,''MM'') AS DISBURSE_MONTH, SUM (DISBURSED_AMOUNT) DISBURSED_AMOUNT,
              TO_CHAR(DISBURSMENT_DATE,''YYMM'') AS DISBURSE_FILTER
			  FROM CRE_MONI_DISB_DATA
              WHERE TRUNC(DISBURSMENT_DATE, ''month'') >= ADD_MONTHS(TRUNC(SYSDATE, ''month''), - 12)
              AND TRUNC(DISBURSMENT_DATE, ''month'') <= TRUNC(SYSDATE, ''month'')
              '||lv_condition1||'              '||lv_condition2||'              '||lv_condition3||'
              GROUP BY '||P_GROUPVAR||', TO_CHAR(DISBURSMENT_DATE,''MM''),TO_CHAR(DISBURSMENT_DATE,''YYMM'')
),
CTE_CALL AS
(
              SELECT '||P_GROUPVAR||',
        DISBURSE_MONTH,
                             DISBURSED_AMOUNT AS CURR_DISBURSED_AMOUNT,
							 DISBURSE_FILTER,
                             LAG(DISBURSED_AMOUNT,1) OVER (PARTITION BY '||P_GROUPVAR||' ORDER BY DISBURSE_FILTER ASC) AS PRIV_DISBURSED_AMOUNT
              FROM CTE_MAIN            
)
SELECT '||P_GROUPVAR||',
              LISTAGG(DISBURSE_MONTH,'', '') WITHIN GROUP(ORDER BY DISBURSE_FILTER DESC) AS DISBURSE_MONTH,
              LISTAGG( case when PRIV_DISBURSED_AMOUNT = 0 then ''na''
              else to_char((ROUND(((CURR_DISBURSED_AMOUNT-PRIV_DISBURSED_AMOUNT)/PRIV_DISBURSED_AMOUNT)*100,2))) end,'','' ) WITHIN GROUP(ORDER BY DISBURSE_FILTER DESC)AS DIFFERENCE
FROM CTE_CALL  GROUP BY '||P_GROUPVAR;

EXCEPTION
  WHEN OTHERS
  THEN
NULL;
END;