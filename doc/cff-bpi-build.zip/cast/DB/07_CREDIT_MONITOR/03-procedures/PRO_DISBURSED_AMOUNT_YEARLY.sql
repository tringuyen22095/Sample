create or replace PROCEDURE PRO_DISBURSED_AMOUNT_YEARLY(P_PRODUCT_NAME IN VARCHAR2 ,
P_ORGANIZATION IN VARCHAR2 , 
P_PROCESS_NAME IN VARCHAR2 , 
CUR_RESPONSE_DETAILS OUT SYS_REFCURSOR,
P_GROUPVAR IN VARCHAR2)
AS
lv_condition1 varchar2(4000);
lv_condition2 varchar2(4000);
lv_condition3 varchar2(4000);

BEGIN

SELECT CASE WHEN P_PROCESS_NAME IS NOT NULL  
             THEN ' and ( nvl(PROCESS_NAME,''xxx'') ='''||P_PROCESS_NAME||''' OR nvl(PROCESS_NAME,''xxx'') = ''TEMP_DATA'')' ELSE ' ' END,
         CASE   WHEN P_PRODUCT_NAME IS NOT NULL 
            --then ' ' else '' end,
            THEN ' and (nvl('||P_GROUPVAR||',''xxx'') = '''||P_PRODUCT_NAME||''' OR nvl('||P_GROUPVAR||',''xxx'') = ''TEMP_DATA'')' ELSE ' ' END,
         CASE   WHEN P_ORGANIZATION  IS NOT NULL 
            THEN ' and( nvl(ORGANIZATION,''xxx'') IN ('||P_ORGANIZATION|| ') OR nvl(ORGANIZATION,''xxx'') = ''TEMP_DATA'')' ELSE ' and nvl(ORGANIZATION,''xxx'') = ''NO_ORG'' ' END
               INTO LV_CONDITION1,
              LV_CONDITION2,
              LV_CONDITION3
    FROM DUAL;
OPEN CUR_RESPONSE_DETAILS
FOR
'WITH    TEMP_DATA ( p, dat, mon, z, monyr, i) AS
        (
        SELECT  distinct '||P_GROUPVAR||', SYSDATE, TO_CHAR(SYSDATE,''MM''),  0, TO_CHAR(SYSDATE,''YYMM'') , 1 from CRE_MONI_DISB_DATA
        UNION ALL
         SELECT  p, ADD_MONTHS(SYSDATE,-i), TO_CHAR(ADD_MONTHS(SYSDATE,-i),''MM''),  0, TO_CHAR(ADD_MONTHS(SYSDATE,-i),''YYMM''), i+1
        FROM    TEMP_DATA
        WHERE   i < 12
),
PRE_CTE_MAIN AS
(SELECT '||P_GROUPVAR||', DISBURSMENT_DATE,DISBURSED_AMOUNT,PROCESS_NAME,ORGANIZATION
FROM CRE_MONI_DISB_DATA
UNION ALL
SELECT p, dat, z,''TEMP_DATA'' , ''TEMP_DATA'' FROM TEMP_DATA),
CTE_MAIN AS
(
              SELECT '||P_GROUPVAR||',TO_CHAR(DISBURSMENT_DATE,''MM'') AS DISBURSE_MONTH, SUM (DISBURSED_AMOUNT) DISBURSED_AMOUNT,
              TO_CHAR(DISBURSMENT_DATE,''YYMM'') AS DISBURSE_FILTER
			  FROM PRE_CTE_MAIN
              WHERE TRUNC(DISBURSMENT_DATE, ''month'') >= ADD_MONTHS(TRUNC(SYSDATE, ''month''), - 12)
              AND TRUNC(DISBURSMENT_DATE, ''month'') <= TRUNC(SYSDATE, ''month'')
              '||lv_condition1||'              '||lv_condition2||'              '||lv_condition3||'
              GROUP BY '||P_GROUPVAR||', TO_CHAR(DISBURSMENT_DATE,''MM''),TO_CHAR(DISBURSMENT_DATE,''YYMM'')
			  
),
CTE_CALL AS
(
              SELECT '||P_GROUPVAR||',
        DISBURSE_MONTH,
                             DISBURSED_AMOUNT AS CURR_DISBURSED_AMOUNT,
							 DISBURSE_FILTER,
                             LAG(DISBURSED_AMOUNT,1) OVER (PARTITION BY '||P_GROUPVAR||' ORDER BY DISBURSE_FILTER ASC) AS PRIV_DISBURSED_AMOUNT
              FROM CTE_MAIN            
), PRE_FINAL AS(
SELECT '||P_GROUPVAR||',
              LISTAGG(DISBURSE_MONTH,'','') WITHIN GROUP(ORDER BY DISBURSE_FILTER ASC) AS DISBURSE_MONTH,
              LISTAGG( case when PRIV_DISBURSED_AMOUNT = 0 then ''null''
			   when CURR_DISBURSED_AMOUNT = 0 then ''null''
              else to_char((ROUND(((CURR_DISBURSED_AMOUNT-PRIV_DISBURSED_AMOUNT)/PRIV_DISBURSED_AMOUNT)*100,2))) end,'','' ) WITHIN GROUP(ORDER BY DISBURSE_FILTER ASC)AS DIFFERENCE
FROM CTE_CALL  GROUP BY '||P_GROUPVAR || ') SELECT * FROM PRE_FINAL WHERE DIFFERENCE NOT IN (
	''0,0,0,0,0,0,0,0,0,0,0,0'',''0,0,0,0,0,0,0,0,0,0,0'', ''0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0'', 
	''null,null,null,null,null,null,null,null,null,null,null,null'', ''null,null,null,null,null,null,null,null,null,null,null'',
  ''null,null,null,null,null,null,null,null,null,null,null,null,null'')';

EXCEPTION
  WHEN OTHERS
  THEN
NULL;
END;