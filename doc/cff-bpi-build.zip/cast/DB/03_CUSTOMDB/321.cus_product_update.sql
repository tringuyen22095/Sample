
-- Delete existing table rows
delete from  "CIPCUSTOM"."CUS_PRODUCT";

-- Add columns in CUS_PRODUCT
ALTER TABLE  "CIPCUSTOM"."CUS_PRODUCT"  ADD( LiveStockFlag VARCHAR2(1) not null);
---------------------------------------------------------------

--CREATE or Replace SYNONYM
-- CREATE OR REPLACE SYNONYM CIPUSERCUSTOM.CUS_PRODUCT for CIPCUSTOM.CUS_PRODUCT;
---------------------------------------------------------------

-- Grant Permission
-- GRANT SELECT, INSERT, UPDATE, DELETE ON CIPCUSTOM.CUS_PRODUCT TO CIPUSERCUSTOM;
---------------------------------------------------------------

commit;