create or replace package CFEXTUSERCUSTOM.PCK_CLIENT is

   procedure SEARCH(
     iORGANIZATIONID NVARCHAR2,
     iCOMPANYNAME NVARCHAR2,
     iREGNUMBER NVARCHAR2,
     RES OUT SYS_REFCURSOR);

	  procedure SEARCHV2(
     iORGANIZATIONID NVARCHAR2,
     iCOMPANYNAME NVARCHAR2,
     iREGNUMBER NVARCHAR2,
     RES OUT SYS_REFCURSOR);

  procedure GETDETAILS(
    iORGANIZATIONID NVARCHAR2,
    iCOMPANYNAME NVARCHAR2,
    iREGNUMBER NVARCHAR2,
    iAPPLICATIONID NVARCHAR2,
    RES OUT SYS_REFCURSOR);

end PCK_CLIENT;
/

create or replace package body CFEXTUSERCUSTOM.PCK_CLIENT is

  procedure SEARCH(iORGANIZATIONID NVARCHAR2, iCOMPANYNAME NVARCHAR2, iREGNUMBER NVARCHAR2, RES OUT SYS_REFCURSOR) is
    begin
      open RES for
        select distinct MAX(DECODE(x.businessfield2, x.businessfield2, x.businessfield2)) CompanyName,
                        MAX(DECODE(x.datasearchfieldcacheid, 'RegNumber', x.valuetext)) RegNumber,
                        MAX(DECODE(x.datasearchfieldcacheid, 'ZipCode', x.valuenumeric)) ZipCode,
                        MAX(DECODE(x.datasearchfieldcacheid, 'Street', x.valuetext)) Street,
                        MAX(DECODE(x.datasearchfieldcacheid, 'City', x.valuetext)) City,
                        MAX(DECODE(x.datasearchfieldcacheid, 'Province', x.valuetext)) Province,
                        MAX(DECODE(x.datasearchfieldcacheid, 'OwnerName', x.valuetext)) OwnerName,
                        MAX(DECODE(x.datasearchfieldcacheid, 'RegistrationDate', x.valuedatetime)) RegDate,
                        MAX(DECODE(x.datasearchfieldcacheid, 'Subdivision', x.valuetext)) Subdivision,
                        MAX(DECODE(x.datasearchfieldcacheid, 'Country', x.valuetext)) Country
        from (
          select
            pe.businessfield2,
		        sd1.processengineguid,
            dsc1.datasearchfieldcacheid,
            sd1.valuedatetime,
            sd1.valuenumeric,
            sd1.valuetext
          from
		        CUSTOMUSER.DATASEARCHFIELDCACHE dsc1
          inner join  CUSTOMUSER.SEARCHDATA sd1
            on (dsc1.datasearchfieldcacheguid = sd1.datasearchfieldcacheguid)
          left join CUSTOMUSER.processengine pe
            on pe.processengineguid = sd1.processengineguid
          where
            sd1.processengineguid in (
              select sd1.processengineguid
              from CUSTOMUSER.DATASEARCHFIELDCACHE dsc1
              inner join CUSTOMUSER.SEARCHDATA sd1
                on (dsc1.datasearchfieldcacheguid = sd1.datasearchfieldcacheguid)
              where
                dsc1.datasearchfieldcacheid = 'RegNumber'
                and upper(sd1.valuetext) = decode(iREGNUMBER, null, sd1.valuetext, upper(iREGNUMBER))
            )
            and sd1.processengineguid in (
              select sd1.processengineguid
              from CUSTOMUSER.DATASEARCHFIELDCACHE dsc1
              inner join CUSTOMUSER.SEARCHDATA sd1
                on (dsc1.datasearchfieldcacheguid = sd1.datasearchfieldcacheguid)
              where
                dsc1.datasearchfieldcacheid = 'OrganizationID'
                and upper(sd1.valuetext) = upper(iORGANIZATIONID)
            )
           and upper(pe.businessfield2) like case
              when iCOMPANYNAME is not null then upper('%' || iCOMPANYNAME || '%')
              else upper(pe.businessfield2)
            end
        ) x
        group by x.processengineguid;
    end SEARCH;

  procedure GETDETAILS(iORGANIZATIONID NVARCHAR2, iCOMPANYNAME NVARCHAR2, iREGNUMBER NVARCHAR2, iAPPLICATIONID NVARCHAR2, RES OUT SYS_REFCURSOR) is
    begin
      open RES for
        select
          APPLICATIONID,
          STARTDATE,
          PHASE,
          XMLCast(XMLQuery('/ProductData/ApprovedProduct/ShortInfo/@LoanAmount' PASSING xmltype(PRODUCTDATA) RETURNING CONTENT) AS NUMBER) LOANAMOUNT,
          APPLICATIONDATA,
          APPLICANTDATA,
          QUESTIONLISTSDATA,
          nvl(FVD, 0) as FieldVisitDone,
          FVDD as FieldVisitDoneDate,
          nvl(QD, 0) as ESTQuestionnaireDone,
          QDD as ESTQuestionnaireDoneDate,
          nvl(QZ, 0) as STQuestionnaireDone,
          QAZ as STQuestionnaireDoneDate,
          FVV as FieldVisitVersion,
          QEV as EstablishedVersion,
          QSV as StartupVersion,
          PIF as PersonalInfoROFlag
        from
           (WITH main_query AS (select pe.applicationid,
                         pe.creationtime,
                         pe.phasecacheid,
                         ddx.datadocumentxml,
                         ddx.datadocumentid
                    from CUSTOMUSER.datadocumentxml ddx,
                         CUSTOMUSER.processengine pe
                    where pe.processengineguid = ddx.processengineguid
                      and pe.businessfield2 = iCOMPANYNAME
                      and pe.processengineguid in (
                        select distinct sd1.processengineguid
                        from CUSTOMUSER.DATASEARCHFIELDCACHE dsc1
                        inner join CUSTOMUSER.SEARCHDATA sd1
                          on (dsc1.datasearchfieldcacheguid = sd1.datasearchfieldcacheguid)
                        where
                          dsc1.datasearchfieldcacheid = 'RegNumber'
                          and upper(sd1.valuetext) = decode(iREGNUMBER, null, sd1.valuetext, upper(iREGNUMBER))
                      )
                      and pe.processengineguid in (
                        select distinct sd1.processengineguid
                        from CUSTOMUSER.DATASEARCHFIELDCACHE dsc1
                        inner join CUSTOMUSER.SEARCHDATA sd1
                          on (dsc1.datasearchfieldcacheguid = sd1.datasearchfieldcacheguid)
                        where
                          dsc1.datasearchfieldcacheid = 'OrganizationID'
                          and upper(sd1.valuetext) = upper(iORGANIZATIONID)
                      )
                      and upper(ddx.datadocumentid) in (upper('APPLICATIONDATA'), upper('APPLICANTDATA'), upper('QUESTIONLISTSDATA'), upper('PRODUCTDATA')))
                   SELECT UPPER(x.applicationid) applicationid,
                          (SELECT distinct trunc(y.creationtime) from main_query y where y.applicationid = x.applicationid) STARTDATE,
                          (SELECT distinct y.phasecacheid from main_query y where y.applicationid = x.applicationid) PHASE,
                          (SELECT y.datadocumentxml FROM main_query y WHERE y.applicationid = x.applicationid AND upper(y.datadocumentid) = upper('APPLICATIONDATA')) APPLICATIONDATA,
                          (SELECT y.datadocumentxml FROM main_query y WHERE y.applicationid = x.applicationid AND upper(y.datadocumentid) = upper('APPLICANTDATA')) APPLICANTDATA,
                          (SELECT y.datadocumentxml FROM main_query y WHERE y.applicationid = x.applicationid AND upper(y.datadocumentid) = upper('QUESTIONLISTSDATA')) QUESTIONLISTSDATA,
                          (SELECT y.datadocumentxml FROM main_query y WHERE y.applicationid = x.applicationid AND upper(y.datadocumentid) = upper('PRODUCTDATA')) PRODUCTDATA
                     FROM (SELECT DISTINCT m.applicationid FROM main_query m) x) Q,
                     XMLTABLE('/ApplicationData/ApplicationInformation' PASSING xmltype(Q.APPLICATIONDATA)
                           COLUMNS
                              FVD VARCHAR2(100) PATH '@FieldVisitDone',
                              FVDD DATE PATH '@FieldVisitDoneDate',
                              QD VARCHAR2(1) PATH '@ESTQuestionnaireDone',
                              QDD DATE PATH '@ESTQuestionnaireDoneDate',
                               QZ VARCHAR2(1) PATH '@STQuestionnaireDone',
                              QAZ DATE PATH '@STQuestionnaireDoneDate',
                              PIF VARCHAR2(100) PATH '@PersonalInfoROFlag'
                           ) as ai,
                     XMLTABLE('/QuestionListsData' PASSING xmltype(Q.QUESTIONLISTSDATA)
                           COLUMNS
                              FVV VARCHAR2(100) PATH 'FieldVisit/@Version',
                              QEV VARCHAR2(100) PATH 'Qualitative/Established/@Version',
                              QSV VARCHAR2(100) PATH 'Qualitative/Startup/@Version'
                           ) as ql
        where APPLICATIONID != iAPPLICATIONID
        order by APPLICATIONID desc;

    end GETDETAILS;

procedure SEARCHV2(iORGANIZATIONID NVARCHAR2, iCOMPANYNAME NVARCHAR2, iREGNUMBER NVARCHAR2, RES OUT SYS_REFCURSOR) is
    begin
      open RES for
        select distinct MAX(DECODE(x.businessfield2, x.businessfield2, x.businessfield2)) CompanyName,
                        MAX(DECODE(x.datasearchfieldcacheid, 'RegNumber', x.valuetext)) RegNumber,
                        MAX(DECODE(x.datasearchfieldcacheid, 'ZipCode', x.valuenumeric)) ZipCode,
                        MAX(DECODE(x.datasearchfieldcacheid, 'Street', x.valuetext)) Street,
                        MAX(DECODE(x.datasearchfieldcacheid, 'City', x.valuetext)) City,
                        MAX(DECODE(x.datasearchfieldcacheid, 'Province', x.valuetext)) Province,
                        MAX(DECODE(x.datasearchfieldcacheid, 'Region', x.valuetext)) Region,
                        MAX(DECODE(x.datasearchfieldcacheid, 'Barangay', x.valuetext)) Barangay,
                        MAX(DECODE(x.datasearchfieldcacheid, 'OwnerName', x.valuetext)) OwnerName,
                        MAX(DECODE(x.datasearchfieldcacheid, 'RegistrationDate', x.valuedatetime)) RegDate,
                        MAX(DECODE(x.datasearchfieldcacheid, 'Subdivision', x.valuetext)) Subdivision,
                        MAX(DECODE(x.datasearchfieldcacheid, 'Country', x.valuetext)) Country,
                        MAX(DECODE(x.datasearchfieldcacheid, 'IndustryType', x.valuetext)) IndustryType,
                        MAX(DECODE(x.datasearchfieldcacheid, 'ActivityType', x.valuetext)) ActivityType,
                        MAX(DECODE(x.datasearchfieldcacheid, 'OperationYears', x.valuenumeric)) OperationYears,
                         MAX(DECODE(x.datasearchfieldcacheid, 'PersonalInfoROFlag', x.valuetext)) PersonalInfoROFlag
                        
                        
                       
        from (
          select
            pe.businessfield2,
            sd1.processengineguid,
            dsc1.datasearchfieldcacheid,
            sd1.valuedatetime,
            sd1.valuenumeric,
            sd1.valuetext
          from
                CUSTOMUSER.DATASEARCHFIELDCACHE dsc1
          inner join  CUSTOMUSER.SEARCHDATA sd1
            on (dsc1.datasearchfieldcacheguid = sd1.datasearchfieldcacheguid)
          left join CUSTOMUSER.processengine pe
            on pe.processengineguid = sd1.processengineguid
          where
            sd1.processengineguid in (
              select sd1.processengineguid
              from CUSTOMUSER.DATASEARCHFIELDCACHE dsc1
              inner join CUSTOMUSER.SEARCHDATA sd1
                on (dsc1.datasearchfieldcacheguid = sd1.datasearchfieldcacheguid)
              where
                dsc1.datasearchfieldcacheid = 'RegNumber'
                and upper(sd1.valuetext) = decode(iREGNUMBER, null, sd1.valuetext, upper(iREGNUMBER))
            )
            and sd1.processengineguid in (
              select sd1.processengineguid
              from CUSTOMUSER.DATASEARCHFIELDCACHE dsc1
              inner join CUSTOMUSER.SEARCHDATA sd1
                on (dsc1.datasearchfieldcacheguid = sd1.datasearchfieldcacheguid)
              where
                dsc1.datasearchfieldcacheid = 'OrganizationID'
                and upper(sd1.valuetext) = upper(iORGANIZATIONID)
            )
            and sd1.processengineguid in (
              select sd1.processengineguid
              from CUSTOMUSER.DATASEARCHFIELDCACHE dsc1
              inner join CUSTOMUSER.SEARCHDATA sd1
                on (dsc1.datasearchfieldcacheguid = sd1.datasearchfieldcacheguid)
              where
                dsc1.datasearchfieldcacheid = 'PersonalInfoROFlag'
                and (sd1.valuetext) = '1'
            )
           and upper(pe.businessfield2) like case
              when iCOMPANYNAME is not null then upper('%' || iCOMPANYNAME || '%')
              else upper(pe.businessfield2)
            end
        ) x
        group by x.processengineguid;
    end SEARCHV2;

end PCK_CLIENT;
/