﻿prompt PL/SQL Developer import file
prompt Created on giovedì 25 luglio 2019 by es539jardudr
set feedback off
set define off
prompt Loading CIPCUSTOM.CUS_PROVINCES...
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (1, 'BASILAN', 1);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (2, 'LANAO DEL SUR', 1);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (3, 'MAGUINDANAO', 1);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (4, 'SULU', 1);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (5, 'TAWI-TAWI', 1);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (6, 'ABRA', 2);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (7, 'APAYAO', 2);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (8, 'BENGUET', 2);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (9, 'IFUGAO', 2);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (10, 'KALINGA', 2);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (11, 'MOUNTAIN PROVINCE', 2);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (12, 'NCR FIRST DISTRICT', 3);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (13, 'NCR FOURTH DISTRICT', 3);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (14, 'NCR SECOND DISTRICT', 3);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (15, 'NCR THIRD DISTRICT', 3);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (16, 'ILOCOS NORTE', 4);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (17, 'ILOCOS SUR', 4);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (18, 'LA UNION', 4);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (19, 'PANGASINAN', 4);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (20, 'BATANES', 5);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (21, 'CAGAYAN', 5);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (22, 'ISABELA', 5);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (23, 'NUEVA VIZCAYA', 5);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (24, 'QUIRINO', 5);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (25, 'AURORA', 6);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (26, 'BATAAN', 6);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (27, 'BULACAN', 6);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (28, 'NUEVA ECIJA', 6);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (29, 'PAMPANGA', 6);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (30, 'TARLAC', 6);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (31, 'ZAMBALES', 6);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (32, 'BATANGAS', 7);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (33, 'CAVITE', 7);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (34, 'LAGUNA', 7);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (35, 'QUEZON', 7);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (36, 'RIZAL', 7);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (37, 'MARINDUQUE', 8);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (38, 'OCCIDENTAL MINDORO', 8);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (39, 'ORIENTAL MINDORO', 8);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (40, 'PALAWAN', 8);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (41, 'ROMBLON', 8);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (42, 'ZAMBOANGA DEL NORTE', 9);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (43, 'ZAMBOANGA DEL SUR', 9);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (44, 'ZAMBOANGA SIBUGAY', 9);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (45, 'ALBAY', 10);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (46, 'CAMARINES NORTE', 10);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (47, 'CAMARINES SUR', 10);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (48, 'CATANDUANES', 10);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (49, 'MASBATE', 10);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (50, 'SORSOGON', 10);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (51, 'AKLAN', 11);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (52, 'ANTIQUE', 11);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (53, 'CAPIZ', 11);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (54, 'GUIMARAS', 11);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (55, 'ILOILO', 11);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (56, 'NEGROS OCCIDENTAL', 11);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (57, 'BOHOL', 12);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (58, 'CEBU', 12);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (59, 'NEGROS ORIENTAL', 12);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (60, 'SIQUIJOR', 12);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (61, 'BILIRAN', 13);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (62, 'EASTERN SAMAR', 13);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (63, 'LEYTE', 13);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (64, 'NORTHERN SAMAR', 13);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (65, 'SAMAR (WESTERN SAMAR)', 13);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (66, 'SOUTHERN LEYTE', 13);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (67, 'BUKIDNON', 14);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (68, 'CAMIGUIN', 14);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (69, 'LANAO DEL NORTE', 14);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (70, 'MISAMIS OCCIDENTAL', 14);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (71, 'MISAMIS ORIENTAL', 14);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (72, 'DAVAO DE ORO', 15);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (73, 'DAVAO DEL NORTE', 15);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (74, 'DAVAO DEL SUR', 15);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (75, 'DAVAO OCCIDENTAL', 15);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (76, 'DAVAO ORIENTAL', 15);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (77, 'COTABATO (NORTH COTABATO)', 16);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (78, 'SARANGANI', 16);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (79, 'SOUTH COTABATO', 16);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (80, 'SULTAN KUDARAT', 16);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (81, 'AGUSAN DEL NORTE', 17);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (82, 'AGUSAN DEL SUR', 17);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (83, 'DINAGAT ISLANDS', 17);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (84, 'SURIGAO DEL NORTE', 17);
insert into CIPCUSTOM.CUS_PROVINCES (provincesid, provincesname, regionid)
values (85, 'SURIGAO DEL SUR', 17);

UPDATE CIPCUSTOM.CUS_PROVINCES
SET provincesname = 'DAVAO DE ORO'
WHERE provincesname = 'COMPOSTELA VALLEY';
commit;
prompt 85 records loaded
set feedback on
set define on
prompt Done.
