﻿prompt PL/SQL Developer import file
prompt Created on giovedì 25 luglio 2019 by es539jardudr
set feedback off
set define off
prompt Loading CIPCUSTOM.CUS_REGION...
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (1, 'AUTONOMOUS REGION IN MUSLIM MINDANAO (ARMM)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (2, 'CORDILLERA ADMINISTRATIVE REGION (CAR)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (3, 'NATIONAL CAPITAL REGION (NCR)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (4, 'REGION I (ILOCOS REGION)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (5, 'REGION II (CAGAYAN VALLEY)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (6, 'REGION III (CENTRAL LUZON)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (7, 'REGION IV-A (CALABARZON)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (8, 'REGION IV-B (MIMAROPA REGION)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (9, 'REGION IX (ZAMBOANGA PENINSULA)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (10, 'REGION V (BICOL REGION)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (11, 'REGION VI (WESTERN VISAYAS)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (12, 'REGION VII (CENTRAL VISAYAS)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (13, 'REGION VIII (EASTERN VISAYAS)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (14, 'REGION X (NORTHERN MINDANAO)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (15, 'REGION XI (DAVAO REGION)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (16, 'REGION XII (SOCCSKSARGEN)');
insert into CIPCUSTOM.CUS_REGION (regionid, regionname)
values (17, 'REGION XIII (Caraga)');
commit;
prompt 17 records loaded
set feedback on
set define on
prompt Done.
