-------------
CREATE TABLE CIPCUSTOM.CUS_ApprovalCommittee  (
	ApprovalCommittee_Id  NUMBER(19) ,
	ID varchar2(100) not null ,
	InstitutionID varchar2(100),
	Name varchar2(100) not null ,
	CONSTRAINT CUS_ApprovalCommittee_PK PRIMARY KEY (ApprovalCommittee_Id) 
) ;

CREATE SEQUENCE CIPCUSTOM.ApprovalCommittee_SEQUENCE MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 5000 NOORDER NOCYCLE;

--GRANT SELECT ON CIPCUSTOM.ApprovalCommittee_SEQUENCE TO CIPUSERCUSTOM;
--CREATE OR REPLACE SYNONYM CIPUSERCUSTOM.ApprovalCommittee_SEQUENCE for CIPCUSTOM.ApprovalCommittee_SEQUENCE;

CREATE OR REPLACE SYNONYM CIPUSERCUSTOM.CUS_ApprovalCommittee for CIPCUSTOM.CUS_ApprovalCommittee;
GRANT SELECT, INSERT, UPDATE, DELETE ON CIPCUSTOM.CUS_ApprovalCommittee TO CIPUSERCUSTOM;

-----------

CREATE TABLE CIPCUSTOM.CUS_ApprovalCommittee_Member  (
	AppComm_Id  NUMBER(19) ,
	Role varchar2(100) not null ,
	LastName varchar2(100) not null,
	FirstName varchar2(100) not null,
	MiddleName varchar2(100) ,
  CONSTRAINT FK_CUS_AppComm_Member FOREIGN KEY (AppComm_Id)
REFERENCES CIPCUSTOM.CUS_ApprovalCommittee (ApprovalCommittee_Id) ON DELETE CASCADE ENABLE, 
	CONSTRAINT CUS_AppComm_Member_PK PRIMARY KEY (AppComm_Id,Role,LastName,FirstName) 
);


CREATE OR REPLACE SYNONYM CIPUSERCUSTOM.CUS_ApprovalCommittee_Member for CIPCUSTOM.CUS_ApprovalCommittee_Member;
GRANT SELECT, INSERT, UPDATE, DELETE ON CIPCUSTOM.CUS_ApprovalCommittee_Member TO CIPUSERCUSTOM;
commit;
