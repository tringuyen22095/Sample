CREATE VIEW CIPLOG.WLOG AS
  select 
       sl.codlogid                connectorid
       , sl.codapplicationid      applicationid
       , sl.codusername           userid
       , sl.coduserasid           userasid
       , sl.codsystemid           systemid
       , sl.codadaptername        adapter_name
       , sl.codadapterversion     adapter_version
       , sldm.codwscategory       category
       , sldm.codwsname           wsname
       , sldm.codwsmethod         wsmethod
       , sl.timrequestdate        adapter_start
       , sl.lobadapterinput       adapter_input
       , sl.lobadapteroutput      adapter_output
       , sl.timenddate            adapter_end
       , sl.coderrorcode          error_code
       , sl.codprocesscacheid     processcacheid
       , sl.codmainapplicantid    main_applicant_id
       , sld.codcallsequence      external_system_call_sequence
	     , sld.status               status
       , sld.timrequestdate       external_system_call_start
       , sld.timenddate           external_system_call_end
       , sld.lobexternalinput     external_system_call_input
       , sld.lobexternaloutput    external_system_call_output
    from CIPLOG.LOG sl
    left join CIPLOG.LOGDETAILS sld on sl.codlogid = sld.codlogid
    left join CIPLOG.LOGDOMAINS sldm on sl.codadaptername = sldm.codadaptername
;

---GRANTS
--GRANT SELECT ON CIPLOG.WLOG TO CIPUSERLOG;

---SYNONYMS
--CREATE OR REPLACE SYNONYM CIPUSERLOG.WLOG for CIPLOG.WLOG;