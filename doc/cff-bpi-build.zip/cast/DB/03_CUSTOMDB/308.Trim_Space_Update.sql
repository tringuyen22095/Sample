update cipcustom.cus_city  set cityname = trim(cityname);

update cipcustom.cus_region  set regionname = trim(regionname);

update cipcustom.cus_provinces  set provincesname = trim(provincesname);

commit;