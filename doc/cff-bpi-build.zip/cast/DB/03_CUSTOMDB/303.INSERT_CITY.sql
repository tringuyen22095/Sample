﻿prompt PL/SQL Developer import file
prompt Created on giovedì 25 luglio 2019 by es539jardudr
set feedback off
set define off
prompt Loading CIPCUSTOM.CUS_CITY...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (324, 'SAN FABIAN', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (325, 'SAN JACINTO', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (326, 'SAN MANUEL', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (327, 'SAN NICOLAS', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (328, 'SAN QUINTIN', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (329, 'SANTA BARBARA', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (330, 'SANTA MARIA', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (331, 'SANTO TOMAS', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (332, 'SISON', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (333, 'SUAL', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (334, 'TAYUG', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (335, 'UMINGAN', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (336, 'URBIZTONDO', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (337, 'VILLASIS', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (338, 'BASCO  ', 20);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (339, 'ITBAYAT', 20);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (340, 'IVANA', 20);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (341, 'MAHATAO', 20);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (342, 'SABTANG', 20);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (343, 'UYUGAN', 20);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (344, 'ABULUG', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (345, 'ALCALA', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (346, 'ALLACAPAN', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (347, 'AMULUNG', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (348, 'APARRI', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (349, 'BAGGAO', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (350, 'BALLESTEROS', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (351, 'BUGUEY', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (352, 'CALAYAN', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (353, 'CAMALANIUGAN', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (354, 'CLAVERIA', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (355, 'ENRILE', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (356, 'GATTARAN', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (357, 'GONZAGA', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (358, 'IGUIG', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (359, 'LAL-LO', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (360, 'LASAM', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (361, 'PAMPLONA', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (362, 'PEÑABLANCA', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (363, 'PIAT', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (364, 'RIZAL', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (365, 'SANCHEZ-MIRA', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (366, 'SANTA ANA', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (367, 'SANTA PRAXEDES', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (368, 'SANTA TERESITA', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (369, 'SANTO NIÑO (FAIRE)', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (370, 'SOLANA', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (371, 'TUAO', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (372, 'TUGUEGARAO CITY  ', 21);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (373, 'ALICIA', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (374, 'ANGADANAN', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (375, 'AURORA', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (376, 'BENITO SOLIVEN', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (377, 'BURGOS', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (378, 'CABAGAN', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (379, 'CABATUAN', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (380, 'CITY OF CAUAYAN', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (381, 'CITY OF SANTIAGO', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (382, 'CORDON', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (383, 'DELFIN ALBANO (MAGSAYSAY)', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (384, 'DINAPIGUE', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (385, 'DIVILACAN', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (386, 'ECHAGUE', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (387, 'GAMU', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (388, 'ILAGAN CITY  ', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (389, 'JONES', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (390, 'LUNA', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (391, 'MACONACON', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (392, 'MALLIG', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (393, 'NAGUILIAN', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (394, 'PALANAN', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (395, 'QUEZON', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (396, 'QUIRINO', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (397, 'RAMON', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (398, 'REINA MERCEDES', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (399, 'ROXAS', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (400, 'SAN AGUSTIN', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (401, 'SAN GUILLERMO', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (402, 'SAN ISIDRO', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (403, 'SAN MANUEL', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (404, 'SAN MARIANO', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (405, 'SAN MATEO', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (406, 'SAN PABLO', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (407, 'SANTA MARIA', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (408, 'SANTO TOMAS', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (409, 'TUMAUINI', 22);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (410, 'ALFONSO CASTANEDA', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (411, 'AMBAGUIO', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (412, 'ARITAO', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (413, 'BAGABAG', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (414, 'BAMBANG', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (415, 'BAYOMBONG  ', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (416, 'DIADI', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (417, 'DUPAX DEL NORTE', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (418, 'DUPAX DEL SUR', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (419, 'KASIBU', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (420, 'KAYAPA', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (421, 'QUEZON', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (422, 'SANTA FE', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (423, 'SOLANO', 23);
commit;
prompt 100 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (424, 'VILLAVERDE', 23);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (425, 'AGLIPAY', 24);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (426, 'CABARROGUIS  ', 24);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (427, 'DIFFUN', 24);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (428, 'MADDELA', 24);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (429, 'NAGTIPUNAN', 24);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (430, 'SAGUDAY', 25);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (431, 'BALER  ', 25);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (432, 'CASIGURAN', 25);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (433, 'DILASAG', 25);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (434, 'DINALUNGAN', 25);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (435, 'DINGALAN', 25);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (436, 'DIPACULAO', 25);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (437, 'MARIA AURORA', 25);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (438, 'SAN LUIS', 25);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (439, 'ABUCAY', 26);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (440, 'BAGAC', 26);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (441, 'CITY OF BALANGA  ', 26);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (442, 'DINALUPIHAN', 26);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (443, 'HERMOSA', 26);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (444, 'LIMAY', 26);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (445, 'MARIVELES', 26);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (446, 'MORONG', 26);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (447, 'ORANI', 26);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (448, 'ORION', 26);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (449, 'PILAR', 26);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (450, 'SAMAL', 26);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (451, 'ANGAT', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (452, 'BALAGTAS (BIGAA)', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (453, 'BALIUAG', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (454, 'BOCAUE', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (455, 'BULACAN', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (456, 'BUSTOS', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (457, 'CALUMPIT', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (458, 'CITY OF MALOLOS  ', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (459, 'CITY OF MEYCAUAYAN', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (460, 'CITY OF SAN JOSE DEL MONTE', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (461, 'DOÑA REMEDIOS TRINIDAD', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (462, 'GUIGUINTO', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (463, 'HAGONOY', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (464, 'MARILAO', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (465, 'NORZAGARAY', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (466, 'OBANDO', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (467, 'PANDI', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (468, 'PAOMBONG', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (469, 'PLARIDEL', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (470, 'PULILAN', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (471, 'SAN ILDEFONSO', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (472, 'SAN MIGUEL', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (473, 'SAN RAFAEL', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (474, 'SANTA MARIA', 27);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (475, 'ALIAGA', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (476, 'BONGABON', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (477, 'CABANATUAN CITY', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (478, 'CABIAO', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (479, 'CARRANGLAN', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (480, 'CITY OF GAPAN', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (481, 'CUYAPO', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (482, 'GABALDON (BITULOK GABALDON)', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (483, 'GENERAL MAMERTO NATIVIDAD', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (484, 'GENERAL TINIO (PAPAYA)', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (485, 'GUIMBA', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (486, 'JAEN', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (487, 'LAUR', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (488, 'LICAB', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (489, 'LLANERA', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (490, 'LUPAO', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (491, 'NAMPICUAN', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (492, 'PALAYAN CITY  ', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (493, 'PANTABANGAN', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (494, 'PEÑARANDA', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (495, 'QUEZON', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (496, 'RIZAL', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (497, 'SAN ANTONIO', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (498, 'SAN ISIDRO', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (499, 'SAN JOSE CITY', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (500, 'SAN LEONARDO', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (501, 'SANTA ROSA', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (502, 'SANTO DOMINGO', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (503, 'SCIENCE CITY OF MUÑOZ', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (504, 'TALAVERA', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (505, 'TALUGTUG', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (506, 'ZARAGOZA', 28);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (507, 'ANGELES CITY', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (508, 'APALIT', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (509, 'ARAYAT', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (510, 'BACOLOR', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (511, 'CANDABA', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (512, 'CITY OF SAN FERNANDO  ', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (513, 'FLORIDABLANCA', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (514, 'GUAGUA', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (515, 'LUBAO', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (516, 'MABALACAT CITY', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (517, 'MACABEBE', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (518, 'MAGALANG', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (519, 'MASANTOL', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (520, 'MEXICO', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (521, 'MINALIN', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (522, 'PORAC', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (523, 'SAN LUIS', 29);
commit;
prompt 200 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (524, 'SAN SIMON', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (525, 'SANTA ANA', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (526, 'SANTA RITA', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (527, 'SANTO TOMAS', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (528, 'SASMUAN (Sexmoan)', 29);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (529, 'ANAO', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (530, 'BAMBAN', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (531, 'CAMILING', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (532, 'CAPAS', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (533, 'CITY OF TARLAC  ', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (534, 'CONCEPCION', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (535, 'GERONA', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (536, 'LA PAZ', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (537, 'MAYANTOC', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (538, 'MONCADA', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (539, 'PANIQUI', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (540, 'PURA', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (541, 'RAMOS', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (542, 'SAN CLEMENTE', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (543, 'SAN JOSE', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (544, 'SAN MANUEL', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (545, 'SANTA IGNACIA', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (546, 'VICTORIA', 30);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (547, 'BOTOLAN', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (548, 'CABANGAN', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (549, 'CANDELARIA', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (550, 'CASTILLEJOS', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (551, 'IBA  ', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (552, 'MASINLOC', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (553, 'OLONGAPO CITY', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (554, 'PALAUIG', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (555, 'SAN ANTONIO', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (556, 'SAN FELIPE', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (557, 'SAN MARCELINO', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (558, 'SAN NARCISO', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (559, 'SANTA CRUZ', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (560, 'SUBIC', 31);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (561, 'AGONCILLO', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (562, 'ALITAGTAG', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (563, 'BALAYAN', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (564, 'BALETE', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (565, 'BATANGAS CITY  ', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (566, 'BAUAN', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (567, 'CALACA', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (568, 'CALATAGAN', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (569, 'CITY OF TANAUAN', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (570, 'CUENCA', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (571, 'IBAAN', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (572, 'LAUREL', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (573, 'LEMERY', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (574, 'LIAN', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (575, 'LIPA CITY', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (576, 'LOBO', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (577, 'MABINI', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (578, 'MALVAR', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (579, 'MATAASNAKAHOY', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (580, 'NASUGBU', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (581, 'PADRE GARCIA', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (582, 'ROSARIO', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (583, 'SAN JOSE', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (584, 'SAN JUAN', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (585, 'SAN LUIS', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (586, 'SAN NICOLAS', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (587, 'SAN PASCUAL', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (588, 'SANTA TERESITA', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (589, 'SANTO TOMAS', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (590, 'TAAL', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (591, 'TALISAY', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (592, 'TAYSAN', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (593, 'TINGLOY', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (594, 'TUY', 32);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (595, 'ALFONSO', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (596, 'AMADEO', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (597, 'BACOOR CITY', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (598, 'CARMONA', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (599, 'CAVITE CITY', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (600, 'CITY OF DASMARIÑAS', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (601, 'CITY OF GENERAL TRIAS', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (602, 'GEN. MARIANO ALVAREZ', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (603, 'GENERAL EMILIO AGUINALDO', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (604, 'IMUS CITY', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (605, 'INDANG', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (606, 'KAWIT', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (607, 'MAGALLANES', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (608, 'MARAGONDON', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (609, 'MENDEZ (MENDEZ-NUÑEZ)', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (610, 'NAIC', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (611, 'NOVELETA', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (612, 'ROSARIO', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (613, 'SILANG', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (614, 'TAGAYTAY CITY', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (615, 'TANZA', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (616, 'TERNATE', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (617, 'TRECE MARTIRES CITY  ', 33);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (618, 'ALAMINOS', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (619, 'BAY', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (620, 'CABUYAO CITY', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (621, 'CALAUAN', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (622, 'CAVINTI', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (623, 'CITY OF BIÑAN', 34);
commit;
prompt 300 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (624, 'CITY OF CALAMBA', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (625, 'CITY OF SAN PEDRO', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (626, 'CITY OF SANTA ROSA', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (627, 'FAMY', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (628, 'KALAYAAN', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (629, 'LILIW', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (630, 'LOS BAÑOS', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (631, 'LUISIANA', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (632, 'LUMBAN', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (633, 'MABITAC', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (634, 'MAGDALENA', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (635, 'MAJAYJAY', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (636, 'NAGCARLAN', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (637, 'PAETE', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (638, 'PAGSANJAN', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (639, 'PAKIL', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (640, 'PANGIL', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (641, 'PILA', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (642, 'RIZAL', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (643, 'SAN PABLO CITY', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (644, 'SANTA CRUZ  ', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (645, 'SANTA MARIA', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (646, 'SINILOAN', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (647, 'VICTORIA', 34);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (648, 'AGDANGAN', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (649, 'ALABAT', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (650, 'ATIMONAN', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (651, 'BUENAVISTA', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (652, 'BURDEOS', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1038, 'GUIMBAL', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (653, 'CALAUAG', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1037, 'ESTANCIA', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1039, 'IGBARAS', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1040, 'ILOILO CITY  ', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1041, 'JANIUAY', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1042, 'LAMBUNAO', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1043, 'LEGANES', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1044, 'LEMERY', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1045, 'LEON', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1046, 'MAASIN', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1047, 'MIAGAO', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1048, 'MINA', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1049, 'NEW LUCENA', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1050, 'OTON', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1051, 'PAVIA', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1052, 'POTOTAN', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1053, 'SAN DIONISIO', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1054, 'SAN ENRIQUE', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1055, 'SAN JOAQUIN', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1056, 'SAN MIGUEL', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1057, 'SAN RAFAEL', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1058, 'SANTA BARBARA', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1059, 'SARA', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1060, 'TIGBAUAN', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1061, 'TUBUNGAN', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1062, 'ZARRAGA', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1063, 'BACOLOD CITY  ', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1064, 'BAGO CITY', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1065, 'BINALBAGAN', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1066, 'CADIZ CITY', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1067, 'CALATRAVA', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1068, 'CANDONI', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1069, 'CAUAYAN', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1070, 'CITY OF ESCALANTE', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1071, 'CITY OF HIMAMAYLAN', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1072, 'CITY OF KABANKALAN', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1073, 'CITY OF SIPALAY', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1074, 'CITY OF TALISAY', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1075, 'CITY OF VICTORIAS', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1076, 'ENRIQUE B. MAGALONA (SARAVIA)', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1077, 'HINIGARAN', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1078, 'HINOBA-AN (ASIA)', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1079, 'ILOG', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1080, 'ISABELA', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1081, 'LA CARLOTA CITY', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1082, 'LA CASTELLANA', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1083, 'MANAPLA', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1084, 'MOISES PADILLA (MAGALLON)', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1085, 'MURCIA', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1086, 'PONTEVEDRA', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1087, 'PULUPANDAN', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1088, 'SAGAY CITY', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1089, 'SALVADOR BENEDICTO', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1090, 'SAN CARLOS CITY', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1091, 'SAN ENRIQUE', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1092, 'SILAY CITY', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1093, 'TOBOSO', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1094, 'VALLADOLID', 56);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1095, 'ALBURQUERQUE', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1096, 'ALICIA', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1097, 'ANDA', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1098, 'ANTEQUERA', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1099, 'BACLAYON', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1100, 'BALILIHAN', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1101, 'BATUAN', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1102, 'BIEN UNIDO', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1103, 'BILAR', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1104, 'BUENAVISTA', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1105, 'CALAPE', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1106, 'CANDIJAY', 57);
commit;
prompt 400 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1107, 'CARMEN', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1108, 'CATIGBIAN', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1109, 'CLARIN', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1110, 'CORELLA', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1111, 'CORTES', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1112, 'DAGOHOY', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1113, 'DANAO', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1114, 'DAUIS', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1115, 'DIMIAO', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1116, 'DUERO', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1117, 'GARCIA HERNANDEZ', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1118, 'GETAFE', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1119, 'GUINDULMAN', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1120, 'INABANGA', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1121, 'JAGNA', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1122, 'LILA', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1123, 'LOAY', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1124, 'LOBOC', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1125, 'LOON', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1126, 'MABINI', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1127, 'MARIBOJOC', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1128, 'PANGLAO', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1129, 'PILAR', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1130, 'PRES. CARLOS P. GARCIA (PITOGO)', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1131, 'SAGBAYAN (BORJA)', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1132, 'SAN ISIDRO', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1133, 'SAN MIGUEL', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1134, 'SEVILLA', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1135, 'SIERRA BULLONES', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1136, 'SIKATUNA', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1137, 'TAGBILARAN CITY  ', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1138, 'TALIBON', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1139, 'TRINIDAD', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1140, 'TUBIGON', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1141, 'UBAY', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1142, 'VALENCIA', 57);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1143, 'ALCANTARA', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1144, 'ALCOY', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1145, 'ALEGRIA', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1146, 'ALOGUINSAN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1147, 'ARGAO', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1148, 'ASTURIAS', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1149, 'BADIAN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1150, 'BALAMBAN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1151, 'BANTAYAN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1152, 'BARILI', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1153, 'BOLJOON', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1154, 'BORBON', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1155, 'CARMEN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1156, 'CATMON', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1157, 'CEBU CITY  ', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1158, 'CITY OF BOGO', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1159, 'CITY OF CARCAR', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1160, 'CITY OF NAGA', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1161, 'CITY OF TALISAY', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1162, 'COMPOSTELA', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1163, 'CONSOLACION', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1164, 'CORDOVA', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1165, 'DAANBANTAYAN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1166, 'DALAGUETE', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1167, 'DANAO CITY', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1168, 'DUMANJUG', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1169, 'GINATILAN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1170, 'LAPU-LAPU CITY (OPON)', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1171, 'LILOAN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1172, 'MADRIDEJOS', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1173, 'MALABUYOC', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1174, 'MANDAUE CITY', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1175, 'MEDELLIN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1176, 'MINGLANILLA', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1177, 'MOALBOAL', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1178, 'OSLOB', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1179, 'PILAR', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1180, 'PINAMUNGAHAN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1181, 'PORO', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1182, 'RONDA', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1183, 'SAMBOAN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1184, 'SAN FERNANDO', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1185, 'SAN FRANCISCO', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1186, 'SAN REMIGIO', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1187, 'SANTA FE', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1188, 'SANTANDER', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1189, 'SIBONGA', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1190, 'SOGOD', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1191, 'TABOGON', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1192, 'TABUELAN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1193, 'TOLEDO CITY', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1194, 'TUBURAN', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1195, 'TUDELA', 58);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1196, 'AMLAN (AYUQUITAN)', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1197, 'AYUNGON', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1198, 'BACONG', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1199, 'BAIS CITY', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1200, 'BASAY', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1201, 'BINDOY (PAYABON)', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1202, 'CANLAON CITY', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1203, 'CITY OF BAYAWAN (TULONG)', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1204, 'CITY OF GUIHULNGAN', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1205, 'CITY OF TANJAY', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1206, 'DAUIN', 59);
commit;
prompt 500 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1207, 'DUMAGUETE CITY  ', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1208, 'JIMALALUD', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1209, 'LA LIBERTAD', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1210, 'MABINAY', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1211, 'MANJUYOD', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1212, 'PAMPLONA', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1213, 'SAN JOSE', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1214, 'SANTA CATALINA', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1215, 'SIATON', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1216, 'SIBULAN', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1217, 'TAYASAN', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1218, 'VALENCIA (LUZURRIAGA)', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1219, 'VALLEHERMOSO', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1220, 'ZAMBOANGUITA', 59);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1221, 'ENRIQUE VILLANUEVA', 60);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1222, 'LARENA', 60);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1223, 'LAZI', 60);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1224, 'MARIA', 60);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1225, 'SAN JUAN', 60);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1226, 'SIQUIJOR  ', 60);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1227, 'ALMERIA', 61);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1228, 'BILIRAN', 61);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1229, 'CABUCGAYAN', 61);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1230, 'CAIBIRAN', 61);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1231, 'CULABA', 61);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1232, 'KAWAYAN', 61);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1233, 'MARIPIPI', 61);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1234, 'NAVAL  ', 61);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1235, 'ARTECHE', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1236, 'BALANGIGA', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1237, 'BALANGKAYAN', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1238, 'CAN-AVID', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1239, 'CITY OF BORONGAN  ', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1240, 'DOLORES', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1241, 'GENERAL MACARTHUR', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1242, 'GIPORLOS', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1243, 'GUIUAN', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1244, 'HERNANI', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1245, 'JIPAPAD', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1246, 'LAWAAN', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1247, 'LLORENTE', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1248, 'MASLOG', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1249, 'MAYDOLONG', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1250, 'MERCEDES', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1251, 'ORAS', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1252, 'QUINAPONDAN', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1253, 'SALCEDO', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1254, 'SAN JULIAN', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1255, 'SAN POLICARPO', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1256, 'SULAT', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1257, 'TAFT', 62);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1258, 'ABUYOG', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1259, 'ALANGALANG', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1260, 'ALBUERA', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1261, 'BABATNGON', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1262, 'BARUGO', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1263, 'BATO', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1264, 'BURAUEN', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1265, 'CALUBIAN', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1266, 'CAPOOCAN', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1267, 'CARIGARA', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1268, 'CITY OF BAYBAY', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1269, 'DAGAMI', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1270, 'DULAG', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1271, 'HILONGOS', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1272, 'HINDANG', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1273, 'INOPACAN', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1274, 'ISABEL', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1275, 'JARO', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1276, 'JAVIER (BUGHO)', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1277, 'JULITA', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1278, 'KANANGA', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1279, 'LA PAZ', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1280, 'LEYTE', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1281, 'MACARTHUR', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1282, 'MAHAPLAG', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1283, 'MATAG-OB', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1284, 'MATALOM', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1285, 'MAYORGA', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1286, 'MERIDA', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1287, 'ORMOC CITY', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1288, 'PALO', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1289, 'PALOMPON', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1290, 'PASTRANA', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1291, 'SAN ISIDRO', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1292, 'SAN MIGUEL', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1293, 'SANTA FE', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1294, 'TABANGO', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1295, 'TABONTABON', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1296, 'TACLOBAN CITY  ', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1297, 'TANAUAN', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1298, 'TOLOSA', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1299, 'TUNGA', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1300, 'VILLABA', 63);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1301, 'ALLEN', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1302, 'BIRI', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1303, 'BOBON', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1304, 'CAPUL', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1305, 'CATARMAN  ', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1306, 'CATUBIG', 64);
commit;
prompt 600 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1307, 'GAMAY', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1308, 'LAOANG', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1309, 'LAPINIG', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1310, 'LAS NAVAS', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1311, 'LAVEZARES', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1312, 'LOPE DE VEGA', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1313, 'MAPANAS', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1314, 'MONDRAGON', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1315, 'PALAPAG', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1316, 'PAMBUJAN', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1317, 'ROSARIO', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1318, 'SAN ANTONIO', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1319, 'SAN ISIDRO', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1320, 'SAN JOSE', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1321, 'SAN ROQUE', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1322, 'SAN VICENTE', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1323, 'SILVINO LOBOS', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1324, 'VICTORIA', 64);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1325, 'ALMAGRO', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1326, 'BASEY', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1327, 'CALBAYOG CITY', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1328, 'CALBIGA', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1329, 'CITY OF CATBALOGAN  ', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1330, 'DARAM', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1331, 'GANDARA', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1332, 'HINABANGAN', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1333, 'JIABONG', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1334, 'MARABUT', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1335, 'MATUGUINAO', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1336, 'MOTIONG', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1337, 'PAGSANGHAN', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1338, 'PARANAS (WRIGHT)', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1339, 'PINABACDAO', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1340, 'SAN JORGE', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1341, 'SAN JOSE DE BUAN', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1342, 'SAN SEBASTIAN', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1343, 'SANTA MARGARITA', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1344, 'SANTA RITA', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1345, 'SANTO NIÑO', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1346, 'TAGAPUL-AN', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1347, 'TALALORA', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1348, 'TARANGNAN', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1349, 'VILLAREAL', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1350, 'ZUMARRAGA', 65);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1351, 'ANAHAWAN', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1352, 'BONTOC', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1353, 'CITY OF MAASIN  ', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1354, 'HINUNANGAN', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1355, 'HINUNDAYAN', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1356, 'LIBAGON', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1357, 'LILOAN', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1358, 'LIMASAWA', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1359, 'MACROHON', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1360, 'MALITBOG', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1361, 'PADRE BURGOS', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1362, 'PINTUYAN', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1363, 'SAINT BERNARD', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1364, 'SAN FRANCISCO', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1365, 'SAN JUAN (CABALIAN)', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1366, 'SAN RICARDO', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1367, 'SILAGO', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1368, 'SOGOD', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1369, 'TOMAS OPPUS', 66);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1370, 'BAUNGON', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1371, 'CABANGLASAN', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1372, 'CITY OF MALAYBALAY  ', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1373, 'CITY OF VALENCIA', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1374, 'DAMULOG', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1375, 'DANGCAGAN', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1376, 'DON CARLOS', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1377, 'IMPASUG-ONG', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1378, 'KADINGILAN', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1379, 'KALILANGAN', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1380, 'KIBAWE', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1381, 'KITAOTAO', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1382, 'LANTAPAN', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1383, 'LIBONA', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1384, 'MALITBOG', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1385, 'MANOLO FORTICH', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1386, 'MARAMAG', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1387, 'PANGANTUCAN', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1388, 'QUEZON', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1389, 'SAN FERNANDO', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1390, 'SUMILAO', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1391, 'TALAKAG', 67);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1392, 'CATARMAN', 68);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1393, 'GUINSILIBAN', 68);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1394, 'MAHINOG', 68);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1395, 'MAMBAJAO  ', 68);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1396, 'SAGAY', 68);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1397, 'BACOLOD', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1398, 'BALOI', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1399, 'BAROY', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1400, 'ILIGAN CITY', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1401, 'KAPATAGAN', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1402, 'KAUSWAGAN', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1403, 'KOLAMBUGAN', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1404, 'LALA', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1405, 'LINAMON', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1406, 'MAGSAYSAY', 69);
commit;
prompt 700 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1407, 'MAIGO', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1408, 'MATUNGAO', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1409, 'MUNAI', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1410, 'NUNUNGAN', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1411, 'PANTAO RAGAT', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1412, 'PANTAR', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1413, 'POONA PIAGAPO', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1414, 'SALVADOR', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1415, 'SAPAD', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1416, 'SULTAN NAGA DIMAPORO (KAROMATAN)', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1417, 'TAGOLOAN', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1418, 'TANGCAL', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1419, 'TUBOD  ', 69);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1420, 'ALORAN', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1421, 'BALIANGAO', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1422, 'BONIFACIO', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1423, 'CALAMBA', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1424, 'CLARIN', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1425, 'CONCEPCION', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1426, 'DON VICTORIANO CHIONGBIAN  (DON MARIANO MARCOS)', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1427, 'JIMENEZ', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1428, 'LOPEZ JAENA', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1429, 'OROQUIETA CITY  ', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1430, 'OZAMIZ CITY', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1431, 'PANAON', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1432, 'PLARIDEL', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1433, 'SAPANG DALAGA', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1434, 'SINACABAN', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1435, 'TANGUB CITY', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1436, 'TUDELA', 70);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1437, 'ALUBIJID', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1438, 'BALINGASAG', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1439, 'BALINGOAN', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1440, 'BINUANGAN', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1441, 'CAGAYAN DE ORO CITY  ', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1442, 'CITY OF EL SALVADOR', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1443, 'CLAVERIA', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1444, 'GINGOOG CITY', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1445, 'GITAGUM', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1446, 'INITAO', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1447, 'JASAAN', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1448, 'KINOGUITAN', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1449, 'LAGONGLONG', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1450, 'LAGUINDINGAN', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1451, 'LIBERTAD', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1452, 'LUGAIT', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1453, 'MAGSAYSAY (LINUGOS)', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1454, 'MANTICAO', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1455, 'MEDINA', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1456, 'NAAWAN', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1457, 'OPOL', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1458, 'SALAY', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1459, 'SUGBONGCOGON', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1460, 'TAGOLOAN', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1461, 'TALISAYAN', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1462, 'VILLANUEVA', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1463, 'COMPOSTELA', 71);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1464, 'LAAK (SAN VICENTE)', 72);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1465, 'MABINI (DOÑA ALICIA)', 72);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1466, 'MACO', 72);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1467, 'MARAGUSAN (SAN MARIANO)', 72);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1468, 'MAWAB', 72);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1469, 'MONKAYO', 72);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1470, 'MONTEVISTA', 72);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1471, 'NABUNTURAN  ', 72);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1472, 'NEW BATAAN', 72);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1473, 'PANTUKAN', 72);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1474, 'ASUNCION (SAUG)', 73);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1475, 'BRAULIO E. DUJALI', 73);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1476, 'CARMEN', 73);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1477, 'CITY OF PANABO', 73);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1478, 'CITY OF TAGUM  ', 73);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1479, 'ISLAND GARDEN CITY OF SAMAL', 73);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1480, 'KAPALONG', 73);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1481, 'NEW CORELLA', 73);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1482, 'SAN ISIDRO', 73);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1483, 'SANTO TOMAS', 73);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1484, 'TALAINGOD', 73);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1485, 'BANSALAN', 74);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1486, 'CITY OF DIGOS  ', 74);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1487, 'DAVAO CITY', 74);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1488, 'HAGONOY', 74);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1489, 'KIBLAWAN', 74);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1490, 'MAGSAYSAY', 74);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1491, 'MALALAG', 74);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1492, 'MATANAO', 74);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1493, 'PADADA', 74);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1494, 'SANTA CRUZ', 74);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1495, 'SULOP', 74);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1496, 'DON MARCELINO', 75);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1497, 'JOSE ABAD SANTOS (TRINIDAD)', 75);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1498, 'MALITA  ', 75);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1499, 'SANTA MARIA', 75);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1500, 'SARANGANI', 75);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1501, 'BAGANGA', 76);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1502, 'BANAYBANAY', 76);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1503, 'BOSTON', 76);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1504, 'CARAGA', 76);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1505, 'CATEEL', 76);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1506, 'CITY OF MATI  ', 76);
commit;
prompt 800 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1507, 'GOVERNOR GENEROSO', 76);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1508, 'LUPON', 76);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1509, 'MANAY', 76);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1510, 'SAN ISIDRO', 76);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1511, 'TARRAGONA', 76);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1512, 'ALAMADA', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1513, 'ALEOSAN', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1514, 'ANTIPAS', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1515, 'ARAKAN', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1516, 'BANISILAN', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1517, 'CARMEN', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1518, 'CITY OF KIDAPAWAN  ', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1519, 'KABACAN', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1520, 'LIBUNGAN', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1521, 'MAGPET', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1522, 'MAKILALA', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1523, 'MATALAM', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1524, 'MIDSAYAP', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1525, 'M''LANG', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1526, 'PIGKAWAYAN', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1527, 'PIKIT', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1528, 'PRESIDENT ROXAS', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1529, 'TULUNAN', 77);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1530, 'ALABEL  ', 78);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1531, 'COTABATO CITY', 78);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1532, 'GLAN', 78);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1533, 'KIAMBA', 78);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1534, 'MAASIM', 78);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1535, 'MAITUM', 78);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1536, 'MALAPATAN', 78);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1537, 'MALUNGON', 78);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1538, 'BANGA', 79);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1539, 'CITY OF KORONADAL  ', 79);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1540, 'GENERAL SANTOS CITY (DADIANGAS)', 79);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1541, 'LAKE SEBU', 79);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1542, 'NORALA', 79);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1543, 'POLOMOLOK', 79);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1544, 'SANTO NIÑO', 79);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1545, 'SURALLAH', 79);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1546, 'TAMPAKAN', 79);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1547, 'TANTANGAN', 79);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1548, 'T''BOLI', 79);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1549, 'TUPI', 79);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1550, 'BAGUMBAYAN', 80);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1551, 'CITY OF TACURONG', 80);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1552, 'COLUMBIO', 80);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1553, 'ESPERANZA', 80);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1554, 'ISULAN  ', 80);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1555, 'KALAMANSIG', 80);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1556, 'LAMBAYONG (MARIANO MARCOS)', 80);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1557, 'LEBAK', 80);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1558, 'LUTAYAN', 80);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1559, 'PALIMBANG', 80);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1560, 'PRESIDENT QUIRINO', 80);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1561, 'SEN. NINOY AQUINO', 80);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1562, 'BUENAVISTA', 81);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1563, 'BUTUAN CITY  ', 81);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1564, 'CARMEN', 81);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1565, 'CITY OF CABADBARAN', 81);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1566, 'JABONGA', 81);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1567, 'KITCHARAO', 81);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1568, 'LAS NIEVES', 81);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1569, 'MAGALLANES', 81);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1570, 'NASIPIT', 81);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1571, 'REMEDIOS T. ROMUALDEZ', 81);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1572, 'SANTIAGO', 81);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1573, 'TUBAY', 81);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1574, 'BUNAWAN', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1575, 'CITY OF BAYUGAN', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1576, 'ESPERANZA', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1577, 'LA PAZ', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1578, 'LORETO', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1579, 'PROSPERIDAD  ', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1580, 'ROSARIO', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1581, 'SAN FRANCISCO', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1582, 'SAN LUIS', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1583, 'SANTA JOSEFA', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1584, 'SIBAGAT', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1585, 'TALACOGON', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1586, 'TRENTO', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1587, 'VERUELA', 82);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1588, 'BASILISA (RIZAL)', 83);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1589, 'CAGDIANAO', 83);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1590, 'DINAGAT', 83);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1591, 'LIBJO (ALBOR)', 83);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1592, 'LORETO', 83);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1593, 'SAN JOSE  ', 83);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1594, 'TUBAJON', 83);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1595, 'ALEGRIA', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1596, 'BACUAG', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1597, 'BURGOS', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1598, 'CLAVER', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1599, 'DAPA', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1600, 'DEL CARMEN', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1601, 'GENERAL LUNA', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1602, 'GIGAQUIT', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1603, 'MAINIT', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1604, 'MALIMONO', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1605, 'PILAR', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1606, 'PLACER', 84);
commit;
prompt 900 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1607, 'SAN BENITO', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1608, 'SAN FRANCISCO (ANAO-AON)', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1609, 'SAN ISIDRO', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1610, 'SANTA MONICA (SAPAO)', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1611, 'SISON', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1612, 'SOCORRO', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1613, 'SURIGAO CITY  ', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1614, 'TAGANA-AN', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1615, 'TUBOD', 84);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1616, 'BAROBO', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1617, 'BAYABAS', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1618, 'CAGWAIT', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1619, 'CANTILAN', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1620, 'CARMEN', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1621, 'CARRASCAL', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1622, 'CITY OF BISLIG', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1623, 'CITY OF TANDAG  ', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1624, 'CORTES', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1625, 'HINATUAN', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1626, 'LANUZA', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1627, 'LIANGA', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1628, 'LINGIG', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1629, 'MADRID', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1630, 'MARIHATAG', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1631, 'SAN AGUSTIN', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1632, 'SAN MIGUEL', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1633, 'TAGBINA', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1634, 'TAGO', 85);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (962, 'ALTAVAS', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (963, 'BALETE', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (964, 'BANGA', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (965, 'BATAN', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (966, 'BURUANGA', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (967, 'IBAJAY', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (968, 'KALIBO  ', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (969, 'LEZO', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (970, 'LIBACAO', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (971, 'MADALAG', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (972, 'MAKATO', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (973, 'MALAY', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (974, 'MALINAO', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (975, 'NABAS', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (976, 'NEW WASHINGTON', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (979, 'ANINI-Y', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (980, 'BARBAZA', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (981, 'BELISON', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (982, 'BUGASONG', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (983, 'CALUYA', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (984, 'CULASI', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (985, 'HAMTIC', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (986, 'LAUA-AN', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (987, 'LIBERTAD', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (988, 'PANDAN', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (989, 'PATNONGON', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (990, 'SAN JOSE  ', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (991, 'SAN REMIGIO', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (992, 'SEBASTE', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (993, 'SIBALOM', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (994, 'TIBIAO', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (995, 'TOBIAS FORNIER (DAO)', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (996, 'VALDERRAMA', 52);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (950, 'CASIGURAN', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (951, 'CASTILLA', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (952, 'CITY OF SORSOGON  ', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (953, 'DONSOL', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (954, 'GUBAT', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (955, 'IROSIN', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (956, 'JUBAN', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (957, 'MAGALLANES', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (958, 'MATNOG', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (959, 'PILAR', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (960, 'PRIETO DIAZ', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (961, 'SANTA MAGDALENA', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (654, 'CANDELARIA', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (655, 'CATANAUAN', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (656, 'CITY OF TAYABAS', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (657, 'DOLORES', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (658, 'GENERAL LUNA', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (659, 'GENERAL NAKAR', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (660, 'GUINAYANGAN', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (661, 'GUMACA', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (662, 'INFANTA', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (663, 'JOMALIG', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (664, 'LOPEZ', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (665, 'LUCBAN', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (666, 'LUCENA CITY  ', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (667, 'MACALELON', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (668, 'MAUBAN', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (669, 'MULANAY', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (670, 'PADRE BURGOS', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (671, 'PAGBILAO', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (672, 'PANUKULAN', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (673, 'PATNANUNGAN', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (674, 'PEREZ', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (675, 'PITOGO', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (676, 'PLARIDEL', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (677, 'POLILLO', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (678, 'QUEZON', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (679, 'REAL', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (680, 'SAMPALOC', 35);
commit;
prompt 1000 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (681, 'SAN ANDRES', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (682, 'SAN ANTONIO', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (683, 'SAN FRANCISCO (AURORA)', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (684, 'SAN NARCISO', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (685, 'SARIAYA', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (686, 'TAGKAWAYAN', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (687, 'TIAONG', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (688, 'UNISAN', 35);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (689, 'ANGONO', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (690, 'BARAS', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (691, 'BINANGONAN', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (692, 'CAINTA', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (693, 'CARDONA', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (694, 'CITY OF ANTIPOLO  ', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (695, 'JALA-JALA', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (696, 'MORONG', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (697, 'PILILLA', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (698, 'RODRIGUEZ (MONTALBAN)', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (699, 'SAN MATEO', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (700, 'TANAY', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (701, 'TAYTAY', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (702, 'TERESA', 36);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (703, 'BOAC  ', 37);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (704, 'BUENAVISTA', 37);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (705, 'GASAN', 37);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (706, 'MOGPOG', 37);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (707, 'SANTA CRUZ', 37);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (708, 'TORRIJOS', 37);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (709, 'ABRA DE ILOG', 38);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (710, 'CALINTAAN', 38);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (711, 'LOOC', 38);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (712, 'LUBANG', 38);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (713, 'MAGSAYSAY', 38);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (714, 'MAMBURAO  ', 38);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (715, 'PALUAN', 38);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (716, 'RIZAL', 38);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (717, 'SABLAYAN', 38);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (718, 'SAN JOSE', 38);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (719, 'SANTA CRUZ', 38);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (720, 'BACO', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (721, 'BANSUD', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (722, 'BONGABONG', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (723, 'BULALACAO (SAN PEDRO)', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (724, 'CITY OF CALAPAN  ', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (725, 'GLORIA', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (726, 'MANSALAY', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (727, 'NAUJAN', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (728, 'PINAMALAYAN', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (729, 'POLA', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (730, 'PUERTO GALERA', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (731, 'ROXAS', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (732, 'SAN TEODORO', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (733, 'SOCORRO', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (734, 'VICTORIA', 39);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (735, 'ABORLAN', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (736, 'AGUTAYA', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (737, 'ARACELI', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (738, 'BALABAC', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (739, 'BATARAZA', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (740, 'BROOKE''S POINT', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (741, 'BUSUANGA', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (742, 'CAGAYANCILLO', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (743, 'CORON', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (744, 'CULION', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (745, 'CUYO', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (746, 'DUMARAN', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (747, 'EL NIDO (BACUIT)', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (748, 'KALAYAAN', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (749, 'LINAPACAN', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (750, 'MAGSAYSAY', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (751, 'NARRA', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (752, 'PUERTO PRINCESA CITY  ', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (753, 'QUEZON', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (754, 'RIZAL (MARCOS)', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (755, 'ROXAS', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (756, 'SAN VICENTE', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (757, 'SOFRONIO ESPAÑOLA', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (758, 'TAYTAY', 40);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (759, 'ALCANTARA', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (760, 'BANTON', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (761, 'CAJIDIOCAN', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (762, 'CALATRAVA', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (763, 'CONCEPCION', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (764, 'CORCUERA', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (765, 'FERROL', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (766, 'LOOC', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (767, 'MAGDIWANG', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (768, 'ODIONGAN', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (769, 'ROMBLON  ', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (770, 'SAN AGUSTIN', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (771, 'SAN ANDRES', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (772, 'SAN FERNANDO', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (773, 'SAN JOSE', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (774, 'SANTA FE', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (775, 'SANTA MARIA (IMELDA)', 41);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (776, 'BACUNGAN (Leon T. Postigo)', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (777, 'BALIGUIAN', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (778, 'DAPITAN CITY', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (779, 'DIPOLOG CITY  ', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (780, 'GODOD', 42);
commit;
prompt 1100 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (781, 'GUTALAC', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (782, 'JOSE DALMAN (PONOT)', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (783, 'KALAWIT', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (784, 'KATIPUNAN', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (785, 'LA LIBERTAD', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (786, 'LABASON', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (787, 'LILOY', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (788, 'MANUKAN', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (789, 'MUTIA', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (790, 'PIÑAN (NEW PIÑAN)', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (791, 'POLANCO', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (792, 'PRES. MANUEL A. ROXAS', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (793, 'RIZAL', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (794, 'SALUG', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (795, 'SERGIO OSMEÑA SR.', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (796, 'SIAYAN', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (797, 'SIBUCO', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (798, 'SIBUTAD', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (799, 'SINDANGAN', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (800, 'SIOCON', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (801, 'SIRAWAI', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (802, 'TAMPILISAN', 42);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (803, 'AURORA', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (804, 'BAYOG', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (805, 'DIMATALING', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (806, 'DINAS', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (807, 'DUMALINAO', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (808, 'DUMINGAG', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (809, 'GUIPOS', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (810, 'JOSEFINA', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (811, 'KUMALARANG', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (812, 'LABANGAN', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (813, 'LAKEWOOD', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (814, 'LAPUYAN', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (815, 'MAHAYAG', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (816, 'MARGOSATUBIG', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (817, 'MIDSALIP', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (818, 'MOLAVE', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (819, 'PAGADIAN CITY  ', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (820, 'PITOGO', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (821, 'RAMON MAGSAYSAY (LIARGO)', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (822, 'SAN MIGUEL', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (823, 'SAN PABLO', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (824, 'SOMINOT (DON MARIANO MARCOS)', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (825, 'TABINA', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (826, 'TAMBULIG', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (827, 'TIGBAO', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (828, 'TUKURAN', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (829, 'VINCENZO A. SAGUN', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (830, 'ZAMBOANGA CITY', 43);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (831, 'ALICIA', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (832, 'BUUG', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (833, 'CITY OF ISABELA', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (834, 'DIPLAHAN', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (835, 'IMELDA', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (836, 'IPIL  ', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (837, 'KABASALAN', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (838, 'MABUHAY', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (839, 'MALANGAS', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (840, 'NAGA', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (841, 'OLUTANGA', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (842, 'PAYAO', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (843, 'ROSELLER LIM', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (844, 'SIAY', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (845, 'TALUSAN', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (846, 'TITAY', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (847, 'TUNGAWAN', 44);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (848, 'BACACAY', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (849, 'CAMALIG', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (850, 'CITY OF LIGAO', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (851, 'CITY OF TABACO', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (852, 'DARAGA (LOCSIN)', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (853, 'GUINOBATAN', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (854, 'JOVELLAR', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (855, 'LEGAZPI CITY  ', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (856, 'LIBON', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (857, 'MALILIPOT', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (858, 'MALINAO', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (859, 'MANITO', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (860, 'OAS', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (861, 'PIO DURAN', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (862, 'POLANGUI', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (863, 'RAPU-RAPU', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (864, 'SANTO DOMINGO (LIBOG)', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (865, 'TIWI', 45);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (866, 'BASUD', 46);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (867, 'CAPALONGA', 46);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (868, 'DAET  ', 46);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (869, 'JOSE PANGANIBAN', 46);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (870, 'LABO', 46);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (871, 'MERCEDES', 46);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (872, 'PARACALE', 46);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (873, 'SAN LORENZO RUIZ (IMELDA)', 46);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (874, 'SAN VICENTE', 46);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (875, 'SANTA ELENA', 46);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (876, 'TALISAY', 46);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (877, 'VINZONS', 46);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (878, 'BAAO', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (879, 'BALATAN', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (880, 'BATO', 47);
commit;
prompt 1200 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (881, 'BOMBON', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (882, 'BUHI', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (883, 'BULA', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (884, 'CABUSAO', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (885, 'CALABANGA', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (886, 'CAMALIGAN', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (887, 'CANAMAN', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (888, 'CARAMOAN', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (889, 'DEL GALLEGO', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (890, 'GAINZA', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (891, 'GARCHITORENA', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (892, 'GOA', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (893, 'IRIGA CITY', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (894, 'LAGONOY', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (895, 'LIBMANAN', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (896, 'LUPI', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (897, 'MAGARAO', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (898, 'MILAOR', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (899, 'MINALABAC', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (900, 'NABUA', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (901, 'NAGA CITY', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (902, 'OCAMPO', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (903, 'PAMPLONA', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (904, 'PASACAO', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (905, 'PILI  ', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (906, 'PRESENTACION (PARUBCAN)', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (907, 'RAGAY', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (908, 'SAGÑAY', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (909, 'SAN FERNANDO', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (910, 'SAN JOSE', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (911, 'SIPOCOT', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (912, 'SIRUMA', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (913, 'TIGAON', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (914, 'TINAMBAC', 47);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (915, 'BAGAMANOC', 48);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (916, 'BARAS', 48);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (917, 'BATO', 48);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (918, 'CARAMORAN', 48);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (919, 'GIGMOTO', 48);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (920, 'PANDAN', 48);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (921, 'PANGANIBAN (PAYO)', 48);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (922, 'SAN ANDRES (CALOLBON)', 48);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (923, 'SAN MIGUEL', 48);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (924, 'VIGA', 48);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (925, 'VIRAC  ', 48);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (926, 'AROROY', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (927, 'BALENO', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (928, 'BALUD', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (929, 'BATUAN', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (930, 'CATAINGAN', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (931, 'CAWAYAN', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (932, 'CITY OF MASBATE  ', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (933, 'CLAVERIA', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (934, 'DIMASALANG', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (935, 'ESPERANZA', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (936, 'MANDAON', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (937, 'MILAGROS', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (938, 'MOBO', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (939, 'MONREAL', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (940, 'PALANAS', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (941, 'PIO V. CORPUZ (LIMBUHAN)', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (942, 'PLACER', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (943, 'SAN FERNANDO', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (944, 'SAN JACINTO', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (945, 'SAN PASCUAL', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (946, 'USON', 49);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (947, 'BARCELONA', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (948, 'BULAN', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (949, 'BULUSAN', 50);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (999, 'DUMALAG', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1000, 'DUMARAO', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1001, 'IVISAN', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1002, 'JAMINDAN', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1003, 'MA-AYON', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1004, 'MAMBUSAO', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1005, 'PANAY', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1006, 'PANITAN', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1007, 'PILAR', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1008, 'PONTEVEDRA', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1009, 'PRESIDENT ROXAS', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1010, 'ROXAS CITY  ', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1011, 'SAPI-AN', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1012, 'SIGMA', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1013, 'TAPAZ', 53);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1014, 'BUENAVISTA', 54);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1015, 'JORDAN  ', 54);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1016, 'NUEVA VALENCIA', 54);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1017, 'SAN LORENZO', 54);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1018, 'SIBUNAG', 54);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1019, 'AJUY', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1020, 'ALIMODIAN', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1021, 'ANILAO', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1022, 'BADIANGAN', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1023, 'BALASAN', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1024, 'BANATE', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1025, 'BAROTAC NUEVO', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1026, 'BAROTAC VIEJO', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1027, 'BATAD', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1028, 'BINGAWAN', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1029, 'CABATUAN', 55);
commit;
prompt 1300 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1030, 'CALINOG', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1031, 'CARLES', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1032, 'CITY OF PASSI', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1033, 'CONCEPCION', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1034, 'DINGLE', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1035, 'DUEÑAS', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1036, 'DUMANGAS', 55);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (249, 'NAGBUKEL', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (250, 'NARVACAN', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (251, 'QUIRINO (ANGKAKI)', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (252, 'SALCEDO (BAUGEN)', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (253, 'SAN EMILIO', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (254, 'SAN ESTEBAN', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (255, 'SAN ILDEFONSO', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (256, 'SAN JUAN (LAPOG)', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (257, 'SAN VICENTE', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (258, 'SANTA', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (259, 'SANTA CATALINA', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (260, 'SANTA CRUZ', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (261, 'SANTA LUCIA', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (262, 'SANTA MARIA', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (263, 'SANTIAGO', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (264, 'SANTO DOMINGO', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (265, 'SIGAY', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (266, 'SINAIT', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (267, 'SUGPON', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (268, 'SUYO', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (269, 'TAGUDIN', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (270, 'AGOO', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (271, 'ARINGAY', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (272, 'BACNOTAN', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (273, 'BAGULIN', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (274, 'BALAOAN', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (275, 'BANGAR', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (276, 'BAUANG', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (277, 'BURGOS', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (278, 'CABA', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (279, 'CITY OF SAN FERNANDO  ', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (280, 'LUNA', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (281, 'NAGUILIAN', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1, 'AKBAR', 1);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (2, 'AL-BARKA', 1);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (3, 'CITY OF LAMITAN  ', 1);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (4, 'HADJI MOHAMMAD AJUL', 1);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (5, 'HADJI MUHTAMAD', 1);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (6, 'LANTAWAN', 1);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (7, 'MALUSO', 1);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (8, 'SUMISIP', 1);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (9, 'TABUAN-LASA', 1);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (10, 'TIPO-TIPO', 1);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (11, 'TUBURAN', 1);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (12, 'UNGKAYA PUKAN', 1);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (13, 'BACOLOD-KALAWI (BACOLOD GRANDE)', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (14, 'BALABAGAN', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (15, 'BALINDONG (WATU)', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (16, 'BAYANG', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (17, 'BINIDAYAN', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (18, 'BUADIPOSO-BUNTONG', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (19, 'BUBONG', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (20, 'BUMBARAN', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (21, 'BUTIG', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (22, 'CALANOGAS', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (23, 'DITSAAN-RAMAIN', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (24, 'GANASSI', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (25, 'KAPAI', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (26, 'KAPATAGAN', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (27, 'LUMBA-BAYABAO (MAGUING)', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (28, 'LUMBACA-UNAYAN', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (29, 'LUMBATAN', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (30, 'LUMBAYANAGUE', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (31, 'MADALUM', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (32, 'MADAMBA', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (33, 'MAGUING', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (34, 'MALABANG', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (35, 'MARANTAO', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (36, 'MARAWI CITY  ', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (37, 'MAROGONG', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (38, 'MASIU', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (39, 'MULONDO', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (40, 'PAGAYAWAN (TATARIKAN)', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (41, 'PIAGAPO', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (42, 'PICONG (SULTAN GUMANDER)', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (43, 'POONA BAYABAO (GATA)', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (44, 'PUALAS', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (45, 'SAGUIARAN', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (46, 'SULTAN DUMALONDONG', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (47, 'TAGOLOAN II', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (48, 'TAMPARAN', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (49, 'TARAKA', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (50, 'TUBARAN', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (51, 'TUGAYA', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (52, 'WAO', 2);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (53, 'AMPATUAN', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (54, 'BARIRA', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (55, 'BULDON', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (56, 'BULUAN', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (57, 'DATU ABDULLAH SANGKI', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (58, 'DATU ANGGAL MIDTIMBANG', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (59, 'DATU BLAH T. SINSUAT', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (60, 'DATU HOFFER AMPATUAN', 3);
commit;
prompt 1400 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (61, 'DATU ODIN SINSUAT (DINAIG)', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (62, 'DATU PAGLAS', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (63, 'DATU PIANG', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (64, 'DATU SALIBO', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (65, 'DATU SAUDI-AMPATUAN', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (66, 'DATU UNSAY', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (67, 'GEN. S.K. PENDATUN', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (68, 'GUINDULUNGAN', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (69, 'KABUNTALAN (TUMBAO)', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (70, 'MAMASAPANO', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (71, 'MANGUDADATU', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (72, 'MATANOG', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (73, 'NORTHERN KABUNTALAN', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (74, 'PAGAGAWAN', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (75, 'PAGALUNGAN', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (76, 'PAGLAT', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (77, 'PANDAG', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (78, 'PARANG', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (79, 'RAJAH BUAYAN', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (80, 'SHARIFF AGUAK (MAGANOY)  ', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (81, 'SHARIFF SAYDONA MUSTAPHA', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (82, 'SOUTH UPI', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (83, 'SULTAN KUDARAT (NULING)', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (84, 'SULTAN MASTURA', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (85, 'SULTAN SA BARONGIS (LAMBAYONG)', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (86, 'TALAYAN', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (87, 'TALITAY', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (88, 'UPI', 3);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (89, 'HADJI PANGLIMA TAHIL (MARUNGGAS)', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (90, 'INDANAN', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (91, 'JOLO  ', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (92, 'KALINGALAN CALUANG', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (93, 'LUGUS', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (94, 'LUUK', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (95, 'MAIMBUNG', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (96, 'OLD PANAMAO', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (97, 'OMAR', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (98, 'PANDAMI', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (99, 'PANGLIMA ESTINO (NEW PANAMAO)', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (100, 'PANGUTARAN', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (101, 'PARANG', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (102, 'PATA', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (103, 'PATIKUL', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (104, 'SIASI', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (105, 'TALIPAO', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (106, 'TAPUL', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (107, 'TONGKIL', 4);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (108, 'BONGAO  ', 5);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (109, 'LANGUYAN', 5);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (110, 'MAPUN (CAGAYAN DE TAWI-TAWI)', 5);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (111, 'PANGLIMA SUGALA (BALIMBING)', 5);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (112, 'SAPA-SAPA', 5);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (113, 'SIBUTU', 5);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (114, 'SIMUNUL', 5);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (115, 'SITANGKAI', 5);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (116, 'SOUTH UBIAN', 5);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (117, 'TANDUBAS', 5);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (118, 'TURTLE ISLANDS', 5);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (119, 'BANGUED  ', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (120, 'BOLINEY', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (121, 'BUCAY', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (122, 'BUCLOC', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (123, 'DAGUIOMAN', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (124, 'DANGLAS', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (125, 'DOLORES', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (126, 'LA PAZ', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (127, 'LACUB', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (128, 'LAGANGILANG', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (129, 'LAGAYAN', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (130, 'LANGIDEN', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (131, 'LICUAN-BAAY (LICUAN)', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (132, 'LUBA', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (133, 'MALIBCONG', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (134, 'MANABO', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (135, 'PEÑARRUBIA', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (136, 'PIDIGAN', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (137, 'PILAR', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (138, 'SALLAPADAN', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (139, 'SAN ISIDRO', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (140, 'SAN JUAN', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (141, 'SAN QUINTIN', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (142, 'TAYUM', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (143, 'TINEG', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (144, 'TUBO', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (145, 'VILLAVICIOSA', 6);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (146, 'CALANASAN (BAYAG)', 7);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (147, 'CONNER', 7);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (148, 'FLORA', 7);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (149, 'KABUGAO  ', 7);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (150, 'LUNA', 7);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (151, 'PUDTOL', 7);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (152, 'SANTA MARCELA', 7);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (153, 'ATOK', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (154, 'BAGUIO CITY', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (155, 'BAKUN', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (156, 'BOKOD', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (157, 'BUGUIAS', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (158, 'ITOGON', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (159, 'KABAYAN', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (160, 'KAPANGAN', 8);
commit;
prompt 1500 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (161, 'KIBUNGAN', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (162, 'LA TRINIDAD  ', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (163, 'MANKAYAN', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (164, 'SABLAN', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (165, 'TUBA', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (166, 'TUBLAY', 8);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (167, 'AGUINALDO', 9);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (168, 'ALFONSO LISTA ', 9);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (169, 'ASIPULO', 9);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (170, 'BANAUE', 9);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (171, 'HINGYON', 9);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (172, 'HUNGDUAN', 9);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (173, 'KIANGAN', 9);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (174, 'LAGAWE  ', 9);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (175, 'LAMUT', 9);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (176, 'MAYOYAO', 9);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (177, 'TINOC', 9);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (178, 'BALBALAN', 10);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (179, 'CITY OF TABUK  ', 10);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (180, 'LUBUAGAN', 10);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (181, 'PASIL', 10);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (182, 'PINUKPUK', 10);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (183, 'RIZAL (LIWAN)', 10);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (184, 'TANUDAN', 10);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (185, 'TINGLAYAN', 10);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (186, 'BARLIG', 11);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (187, 'BAUKO', 11);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (188, 'BESAO', 11);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (189, 'BONTOC  ', 11);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (190, 'NATONIN', 11);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (191, 'PARACELIS', 11);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (192, 'SABANGAN', 11);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (193, 'SADANGA', 11);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (194, 'SAGADA', 11);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (195, 'TADIAN', 11);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (196, 'CITY OF MANILA', 12);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (197, 'CITY OF LAS PIÑAS', 13);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (198, 'CITY OF MAKATI', 13);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (199, 'CITY OF MUNTINLUPA', 13);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (200, 'CITY OF PARAÑAQUE', 13);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (201, 'PASAY CITY', 13);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (202, 'PATEROS', 13);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (203, 'TAGUIG CITY', 13);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (204, 'CITY OF MANDALUYONG', 14);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (205, 'CITY OF MARIKINA', 14);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (206, 'CITY OF PASIG', 14);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (207, 'CITY OF SAN JUAN', 14);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (208, 'QUEZON CITY', 14);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (209, 'CALOOCAN CITY', 15);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (210, 'CITY OF MALABON', 15);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (211, 'CITY OF NAVOTAS', 15);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (212, 'CITY OF VALENZUELA', 15);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (213, 'ADAMS', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (214, 'BACARRA', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (215, 'BADOC', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (216, 'BANGUI', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (217, 'BANNA (ESPIRITU)', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (218, 'BURGOS', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (219, 'CARASI', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (220, 'CITY OF BATAC', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (221, 'CURRIMAO', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (222, 'DINGRAS', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (223, 'DUMALNEG', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (224, 'LAOAG CITY  ', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (225, 'MARCOS', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (226, 'NUEVA ERA', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (227, 'PAGUDPUD', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (228, 'PAOAY', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (229, 'PASUQUIN', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (230, 'PIDDIG', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (231, 'PINILI', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (232, 'SAN NICOLAS', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (233, 'SARRAT', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (234, 'SOLSONA', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (235, 'VINTAR', 16);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (236, 'ALILEM', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (237, 'BANAYOYO', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (238, 'BANTAY', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (239, 'BURGOS', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (240, 'CABUGAO', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (241, 'CAOAYAN', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (242, 'CERVANTES', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (243, 'CITY OF CANDON', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (244, 'CITY OF VIGAN  ', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (245, 'GALIMUYOD', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (246, 'GREGORIO DEL PILAR (CONCEPCION)', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (247, 'LIDLIDDA', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (248, 'MAGSINGAL', 17);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (282, 'PUGO', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (283, 'ROSARIO', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (284, 'SAN GABRIEL', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (285, 'SAN JUAN', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (286, 'SANTO TOMAS', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (287, 'SANTOL', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (288, 'SUDIPEN', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (289, 'TUBAO', 18);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (290, 'AGNO', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (291, 'AGUILAR', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (292, 'ALCALA', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (293, 'ANDA', 19);
commit;
prompt 1600 records committed...
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (294, 'ASINGAN', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (295, 'BALUNGAO', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (296, 'BANI', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (297, 'BASISTA', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (298, 'BAUTISTA', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (299, 'BAYAMBANG', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (300, 'BINALONAN', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (301, 'BINMALEY', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (302, 'BOLINAO', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (303, 'BUGALLON', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (304, 'BURGOS', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (305, 'CALASIAO', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (306, 'CITY OF ALAMINOS', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (307, 'CITY OF URDANETA', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (308, 'DAGUPAN CITY', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (309, 'DASOL', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (310, 'INFANTA', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (311, 'LABRADOR', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (312, 'LAOAC', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (313, 'LINGAYEN  ', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (314, 'MABINI', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (315, 'MALASIQUI', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (316, 'MANAOAG', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (317, 'MANGALDAN', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (318, 'MANGATAREM', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (319, 'MAPANDAN', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (320, 'NATIVIDAD', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (321, 'POZORRUBIO', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (322, 'ROSALES', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (323, 'SAN CARLOS CITY', 19);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (1635, 'SAGUDAY', 24);

insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (977, 'TANGALAN', 51);
insert into CIPCUSTOM.CUS_CITY (cityid, cityname, provincesid)
values (978, 'NUMANCIA', 51);
commit;
prompt 1630 records loaded
set feedback on
set define on
prompt Done.
