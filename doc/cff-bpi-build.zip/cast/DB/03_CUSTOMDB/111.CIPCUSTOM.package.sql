create or replace package CIPCUSTOM.PCKNOTIFICATIONS is

  procedure prScheduleEMail(iEMAILID varchar2, iSCHEDULEDATE date, iEMAILXML varchar2);
  
  procedure prUpdateEMail(iEMAILID varchar2, iSTATUS varchar2 , iSTATUSMESSAGE varchar2, iDELIVERYDATE date, iRUNID number);
      
  procedure prLoadEMails(RES out sys_refcursor);
  
  procedure prLoadExecutionRecap(iRUNID number, RES out sys_refcursor);

end PCKNOTIFICATIONS;
/

create or replace package body CIPCUSTOM.PCKNOTIFICATIONS is

  procedure prScheduleEMail(iEMAILID varchar2, iSCHEDULEDATE date, iEMAILXML varchar2) is
    begin
      
    insert into LOSTEMAILS
      (id, scheduledate, email, status, statusmessage, deliverydate, runid)
    values
      (iEMAILID, iSCHEDULEDATE, iEMAILXML, 'SCHEDULED', null, null, null);    
      
  end prScheduleEMail;
  
  procedure prUpdateEMail(iEMAILID varchar2, iSTATUS varchar2 , iSTATUSMESSAGE varchar2, iDELIVERYDATE date, iRUNID number) is
    begin
      update LOSTEMAILS
         set status = iSTATUS,
             statusmessage = iSTATUSMESSAGE,
             deliverydate = iDELIVERYDATE,
             runid = iRUNID
       where id = iEMAILID;
    
  end prUpdateEMail;
  
  procedure prLoadEMails(RES out sys_refcursor) is
    begin
      open RES for
        select 
          e.id, e.scheduledate, e.email
        from
          LOSTEMAILS e
        where 
          e.status != 'SENT'
          and trunc(sysdate) >= trunc(e.scheduledate);          
      
  end prLoadEMails;
  
  procedure prLoadExecutionRecap(iRUNID number, RES out sys_refcursor) is
    begin
      open RES for
        select 
          e.id, 
          e.scheduledate, 
          e.status, 
          e.statusmessage, 
          e.deliverydate,
          extractvalue(value(xmlnode), '/EMail/Template/@Name', '') templateName
        from 
          LOSTEMAILS e,
          Table(XMLSequence(extract(xmltype(e.email), '/*', null))) xmlnode
        where 
          e.runid = iRUNID;
     
  end prLoadExecutionRecap;
  
end PCKNOTIFICATIONS;
/

---GRANTS
--GRANT EXECUTE on CIPCUSTOM.PCKNOTIFICATIONS TO CIPUSERCUSTOM;

---SYNONYMS
--CREATE OR REPLACE SYNONYM CIPUSERCUSTOM.PCKNOTIFICATIONS for CIPCUSTOM.PCKNOTIFICATIONS;