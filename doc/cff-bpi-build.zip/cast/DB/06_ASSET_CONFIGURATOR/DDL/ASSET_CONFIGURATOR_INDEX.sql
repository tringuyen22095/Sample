--------------------------------------------------------
--  INDEX for Table APPROVAL_RANGE
--------------------------------------------------------
CREATE INDEX APPROVAL_RANGE_ASSET_TYPE ON APPROVAL_RANGE (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table APPROVAL_RANGE_DEFINITION
--------------------------------------------------------
CREATE INDEX APPROVAL_RANGE_DEFINITION_APP_RANGE_ID ON APPROVAL_RANGE_DEFINITION (APP_RANGE_ID);

--------------------------------------------------------
--  INDEX for Table ASSET
--------------------------------------------------------
CREATE INDEX ASSET_ASSET_NAME ON ASSET (ASSET_NAME);

--------------------------------------------------------
--  INDEX for Table ORG_ASSET
--------------------------------------------------------
CREATE INDEX ORG_ASSET_ASSET_ID ON ORG_ASSET (ASSET_ID);

--------------------------------------------------------
--  INDEX for Table ASSET_GENERAL_SETTING
--------------------------------------------------------
CREATE INDEX ASSET_GENERAL_SETTING_ASSET_TYPE ON ASSET_GENERAL_SETTING (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table COLLATERALS
--------------------------------------------------------
CREATE INDEX COLLATERALS_ASSET_TYPE ON COLLATERALS (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table CUS_APPROVALCOMMITTEE
--------------------------------------------------------
CREATE INDEX CUS_APPROVALCOMMITTEE_ASSET_TYPE ON CUS_APPROVALCOMMITTEE (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table CUS_APPROVALCOMMITTEE_MEMBER
--------------------------------------------------------
CREATE INDEX CUS_APPROVALCOMMITTEE_MEMBER_APPCOMM_ID ON CUS_APPROVALCOMMITTEE_MEMBER (APPCOMM_ID);

--------------------------------------------------------
--  INDEX for Table DECISION_ROLE_MATRIX
--------------------------------------------------------
CREATE INDEX DECISION_ROLE_MATRIX_ASSET_TYPE ON DECISION_ROLE_MATRIX (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table RULE_MATRIX_KEYVALUE
--------------------------------------------------------
CREATE INDEX RULE_MATRIX_KEYVALUE_MATRIX_ID ON RULE_MATRIX_KEYVALUE (MATRIX_ID);

--------------------------------------------------------
--  INDEX for Table DOCUMENTS
--------------------------------------------------------
CREATE INDEX DOCUMENTS_ASSET_TYPE ON DOCUMENTS (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table FEE_MASTER
--------------------------------------------------------
CREATE INDEX FEE_MASTER_ASSET_TYPE ON FEE_MASTER (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table FORM_OBJECT_CONFIG
--------------------------------------------------------
CREATE INDEX FORM_OBJECT_CONFIG_ASSET_TYPE ON FORM_OBJECT_CONFIG (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table LIST_LIBRARY
--------------------------------------------------------
CREATE INDEX LIST_LIBRARY_ASSET_TYPE ON LIST_LIBRARY (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table LIST_LIBRARY_ELEMENT
--------------------------------------------------------
CREATE INDEX LIST_LIBRARY_ELEMENT_LIST_ID ON LIST_LIBRARY_ELEMENT (LIST_ID);

--------------------------------------------------------
--  INDEX for Table NIR_RANGE
--------------------------------------------------------
CREATE INDEX NIR_RANGE_ASSET_TYPE ON NIR_RANGE (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table NIR_RANGE_DEFINITION
--------------------------------------------------------
CREATE INDEX NIR_RANGE_DEFINITION_LIST_ID ON NIR_RANGE_DEFINITION (NIR_ID);

--------------------------------------------------------
--  INDEX for Table PARAMETERS
--------------------------------------------------------
CREATE INDEX PARAMETERS_CATEGORY_NAME_ASSET_TYPE ON PARAMETERS (
	CATEGORY_NAME
	,ASSET_TYPE
	);

--------------------------------------------------------*
--  INDEX for Table ORG_USER_DEFINED_FIELDS
--------------------------------------------------------
CREATE INDEX ORG_USER_DEFINED_FIELDS_ORG_NAME_ASSET_TYPE ON ORG_USER_DEFINED_FIELDS (
	ORGANIZATION_NAME
	,ASSET_TYPE
	);

--------------------------------------------------------
--  INDEX for Table USER_DEFINED_FIELD_DETAILS
--------------------------------------------------------
CREATE INDEX USER_DEFINED_FIELD_DETAILS_ASSET_TYPE ON USER_DEFINED_FIELD_DETAILS (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table ORGANIZATION_SOLUTION_SETTINGS
--------------------------------------------------------
CREATE INDEX ORGANIZATION_SOLUTION_SETTINGS_ASSET_TYPE ON ORGANIZATION_SOLUTION_SETTINGS (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table SOLUTION_SETTINGS
--------------------------------------------------------
CREATE INDEX SOLUTION_SETTINGS_ORG_SOL_ID ON SOLUTION_SETTINGS (ORG_SOL_ID);

--------------------------------------------------------
--  INDEX for Table SOLUTION_FIELD_CONFIG
--------------------------------------------------------
CREATE INDEX SOLUTION_SETTINGS_ASSET_TYPE ON SOLUTION_FIELD_CONFIG (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table RULE_MASTER
--------------------------------------------------------
CREATE INDEX RULE_MASTER_RULE_ASSET_TYPE ON RULE_MASTER (
	RULE_TYPE
	,ASSET_TYPE
	);

--------------------------------------------------------
--  INDEX for Table RULE_PARAMETER
--------------------------------------------------------
CREATE INDEX RULE_PARAMETER_ASSET_TYPE ON RULE_PARAMETER (ASSET_TYPE);

--------------------------------------------------------
--  INDEX for Table PRODUCT_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_LIVE_PRODUCT_TYPE_PRODUCT_STATUS ON PRODUCT_LIVE (
	PRODUCT_TYPE
	,PRODUCT_STATUS
	);

--------------------------------------------------------
--  INDEX for Table PRODUCT_APPROVAL_RANGE_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_APPROVAL_RANGE_LIVE_PRODUCT_ID ON PRODUCT_APPROVAL_RANGE_LIVE (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_APP_RANGE_DEF_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_APP_RANGE_DEF_LIVE_PRODUCT_APP_RANGE_ID ON PRODUCT_APP_RANGE_DEF_LIVE (PRODUCT_APP_RANGE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_APPCOM_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_APPCOM_LIVE_LIVE_PRODUCT_ID ON PRODUCT_APPCOM_LIVE (LIVE_PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_APPCOM_MEMBER_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_APPCOM_MEMBER_LIVE_PRODUCT_APPCOM_LIVE_ID ON PRODUCT_APPCOM_MEMBER_LIVE (PRODUCT_APPCOM_LIVE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_COLLATERALS_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_COLLATERALS_LIVE_PRODUCT_LIVE_ID ON PRODUCT_COLLATERALS_LIVE (PRODUCT_LIVE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_DEC_ROLE_MATRIX_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_DEC_ROLE_MATRIX_LIVE_LIVE_PRODUCT_ID ON PRODUCT_DEC_ROLE_MATRIX_LIVE (LIVE_PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_MATRIX_KEYVALUE_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_MATRIX_KEYVALUE_LIVE_PROD_MATRIX_LIVE_ID ON PRODUCT_MATRIX_KEYVALUE_LIVE (PROD_MATRIX_LIVE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_DOCUMENTS_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_DOCUMENTS_LIVE_PRODUCT_LIVE_ID ON PRODUCT_DOCUMENTS_LIVE (PRODUCT_LIVE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_FEE_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_FEE_LIVE_PRODUCT_ID ON PRODUCT_FEE_LIVE (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_NIR_RANGE_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_NIR_RANGE_LIVE_LIVE_PRODUCT_ID ON PRODUCT_NIR_RANGE_LIVE (LIVE_PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_NIR_RANGE_DEF_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_NIR_RANGE_DEF_LIVE_PRODUCT_NIR_RANGE_LIVE_ID ON PRODUCT_NIR_RANGE_DEF_LIVE (PRODUCT_NIR_RANGE_LIVE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_PARAMETER_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_PARAMETER_LIVE_LIVE_PRODUCT_ID ON PRODUCT_PARAMETER_LIVE (LIVE_PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_RULE_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_RULE_LIVE_LIVE_PRODUCT_ID ON PRODUCT_RULE_LIVE (LIVE_PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_RULE_PARAMETER_LIVE
--------------------------------------------------------
CREATE INDEX PRODUCT_RULE_PARAMETER_LIVE_PRODUCT_RULE_ID ON PRODUCT_RULE_PARAMETER_LIVE (PRODUCT_RULE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT
--------------------------------------------------------
CREATE INDEX PRODUCT_PROD_STATUS_ASSET_TYPE ON PRODUCT (
	PROD_STATUS
	,ASSET_TYPE
	);

--------------------------------------------------------
--  INDEX for Table PRODUCT_APPRCOM
--------------------------------------------------------
CREATE INDEX PRODUCT_APPRCOM_PRODUCT_ID ON PRODUCT_APPRCOM (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_APPROVAL_RANGE
--------------------------------------------------------
CREATE INDEX PRODUCT_APPROVAL_RANGE_PRODUCT_ID ON PRODUCT_APPROVAL_RANGE (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_COLLATERALS
--------------------------------------------------------
CREATE INDEX PRODUCT_COLLATERALS_PRODUCT_ID ON PRODUCT_COLLATERALS (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_DECISION_ROLE_MATRIX
--------------------------------------------------------
CREATE INDEX PRODUCT_DECISION_ROLE_MATRIX_PRODUCT_ID ON PRODUCT_DECISION_ROLE_MATRIX (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_DOCUMENTS
--------------------------------------------------------
CREATE INDEX PRODUCT_DOCUMENTS_PRODUCT_ID ON PRODUCT_DOCUMENTS (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_FEE
--------------------------------------------------------
CREATE INDEX PRODUCT_FEE_PRODUCT_ID ON PRODUCT_FEE (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_RULE
--------------------------------------------------------
CREATE INDEX PRODUCT_RULE_PRODUCT_ID ON PRODUCT_RULE (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_RULE_PARAMETER
--------------------------------------------------------
CREATE INDEX PRODUCT_RULE_PARAMETER_PRODUCT_RULE_ID ON PRODUCT_RULE_PARAMETER (PRODUCT_RULE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_PARAMETER
--------------------------------------------------------
CREATE INDEX PRODUCT_PARAMETER_PRODUCT_ID ON PRODUCT_PARAMETER (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_NIR_RANGE
--------------------------------------------------------
CREATE INDEX PRODUCT_NIR_RANGE_PRODUCT_ID ON PRODUCT_NIR_RANGE (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_LIST_LIBRARY
--------------------------------------------------------
CREATE INDEX PRODUCT_LIST_LIBRARY_PRODUCT_ID ON PRODUCT_LIST_LIBRARY (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_GENERAL_SETTING
--------------------------------------------------------
CREATE INDEX PRODUCT_GENERAL_SETTING_PRODUCT_ID ON PRODUCT_GENERAL_SETTING (PRODUCT_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_TYPE
--------------------------------------------------------
CREATE INDEX PRODUCT_TYPE_TEMP_STATUS_ASSET_TYPE ON PRODUCT_TYPE (
	TEMPLATE_STATUS
	,ASSET_TYPE
	);

--------------------------------------------------------
--  INDEX for Table PRODUCT_TYPE_PARAM_TEMPLATE
--------------------------------------------------------
CREATE INDEX PRODUCT_TYPE_PARAM_TEMPLATE_PRODUCT_TYPE_ID ON PRODUCT_TYPE_PARAM_TEMPLATE (PRODUCT_TYPE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_TYPE_NIR_TEMPLATE
--------------------------------------------------------
CREATE INDEX PRODUCT_TYPE_NIR_TEMPLATE_PRODUCT_TYPE_ID ON PRODUCT_TYPE_NIR_TEMPLATE (PRODUCT_TYPE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_TYPE_LIST_LIB_TEMPLATE
--------------------------------------------------------
CREATE INDEX PRODUCT_TYPE_LIST_LIB_TEMPLATE_PRODUCT_TYPE_ID ON PRODUCT_TYPE_LIST_LIB_TEMPLATE (PRODUCT_TYPE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_TYPE_GEN_SET_TEMPLATE
--------------------------------------------------------
CREATE INDEX PRODUCT_TYPE_GEN_SET_TEMPLATE_PRODUCT_TYPE_ID ON PRODUCT_TYPE_GEN_SET_TEMPLATE (PRODUCT_TYPE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_TYPE_FEE_TEMPLATE
--------------------------------------------------------
CREATE INDEX PRODUCT_TYPE_FEE_TEMPLATE_PRODUCT_TYPE_ID ON PRODUCT_TYPE_FEE_TEMPLATE (PRODUCT_TYPE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_TYPE_DRM_TEMPLATE
--------------------------------------------------------
CREATE INDEX PRODUCT_TYPE_DRM_TEMPLATE_PRODUCT_TYPE_ID ON PRODUCT_TYPE_DRM_TEMPLATE (PRODUCT_TYPE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_TYPE_DOC_TEMPLATE
--------------------------------------------------------
CREATE INDEX PRODUCT_TYPE_DOC_TEMPLATE_PRODUCT_TYPE_ID ON PRODUCT_TYPE_DOC_TEMPLATE (PRODUCT_TYPE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_TYPE_COLLT_TEMPLATE
--------------------------------------------------------
CREATE INDEX PRODUCT_TYPE_COLLT_TEMPLATE_PRODUCT_TYPE_ID ON PRODUCT_TYPE_COLLT_TEMPLATE (PRODUCT_TYPE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_TYPE_APPR_TEMPLATE
--------------------------------------------------------
CREATE INDEX PRODUCT_TYPE_APPR_TEMPLATE_PRODUCT_TYPE_ID ON PRODUCT_TYPE_APPR_TEMPLATE (PRODUCT_TYPE_ID);

--------------------------------------------------------
--  INDEX for Table PRODUCT_TYPE_APPCOM_TEMPLATE
--------------------------------------------------------
CREATE INDEX PRODUCT_TYPE_APPCOM_TEMPLATE_PRODUCT_TYPE_ID ON PRODUCT_TYPE_APPCOM_TEMPLATE (PRODUCT_TYPE_ID);

--------------------------------------------------------
--  INDEX for Table ASSET_RULE_TEMPLATE
--------------------------------------------------------
CREATE INDEX ASSET_RULE_TEMPLATE_PRODUCT_TYPE_ID ON ASSET_RULE_TEMPLATE (PRODUCT_TYPE_ID);

--------------------------------------------------------
--  INDEX for Table ASSET_RULE_PARAMETER_TEMPLATE
--------------------------------------------------------
CREATE INDEX ASSET_RULE_PARAMETER_TEMPLATE_ASSET_RULE_ID ON ASSET_RULE_PARAMETER_TEMPLATE (ASSET_RULE_ID);
